# Neon Logic 3D
Native Android (Kotlin, Jetpack Compose UI, Google Filament 1.52.2 rendering, DataStore persistence).

## Open / build / run
1. Android Studio (Koala or newer), JDK 17, Android SDK 34. `File > Open` this folder and let Gradle sync
   (Android Studio generates the Gradle wrapper jar; or run `gradle wrapper --gradle-version 8.7` once).
2. Debug APK: `./gradlew :app:assembleDebug` -> `app/build/outputs/apk/debug/`
3. Unit tests (engine, 100-level validation, persistence codecs): `./gradlew :app:testDebugUnitTest`
4. Release bundle: `./gradlew :app:bundleRelease` (configure your own signing config; no keystore is included).

## Architecture
- `domain.model / domain.puzzle / domain.solver`: pure Kotlin, no Android. Bitmask ports (N=1,E=2,S=4,W=8), BFS validator over
  reciprocal ports, deterministic `PuzzleEngine` (rotate/undo/restart/hint), exhaustive minimum-move `Solver`.
- `data.levels`: versioned `levels.json` (assets) parser. `data.persistence`: DataStore progress + settings with defensive codecs.
- `graphics.BoardRenderer`: Filament scene built from procedural cube meshes + runtime-compiled PBR material (filamat). Reads `PuzzleState` only.
- `ui`: Compose screens (splash, menu, chapters, levels, game, pause, complete, settings, daily, tutorial). `audio`: synthesized SFX/music, audio focus, haptics.

## Levels
`tools/generate_levels.py` generates the 100 levels deterministically and refuses to emit any level the exhaustive solver cannot solve;
`par` is the proven minimum move count. Regenerate: `python3 tools/generate_levels.py`.
Rule: a level is complete when BFS over reciprocal ports reaches the target; extra dangling branches are allowed.
