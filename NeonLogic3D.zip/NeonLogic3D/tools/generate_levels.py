#!/usr/bin/env python3
"""Deterministic generator + independent solver/validator for Neon Logic 3D levels.
Output: app/src/main/assets/levels.json  (every level is solved by exhaustive search before being written).
Tile token: <type><orientation 0-3>[!]   types: I straight, L elbow, T three-way, X four-way,
O source, G target, # blocked, . decorative empty.  '!' = fixed (not rotatable).
Bitmask: N=1 E=2 S=4 W=8; rotating clockwise by 90deg: ((m<<1)|(m>>3))&15.
"""
import json, random, sys, os
N,E,S,W = 1,2,4,8
DIRS = [(N,-1,0),(E,0,1),(S,1,0),(W,0,-1)]
OPP = {N:S,S:N,E:W,W:E}
BASE = {'I':N|S,'L':N|E,'T':N|E|W,'X':15,'O':N,'G':N,'#':0,'.':0}
ALWAYS_FIXED = set('OG#.')
def rot(m,k):
    for _ in range(k % 4): m = ((m<<1)|(m>>3)) & 15
    return m
def parse(rows):
    g=[]
    for line in rows:
        r=[]
        for tok in line.split():
            t=tok[0]; o=int(tok[1]); fixed = tok.endswith('!') or t in ALWAYS_FIXED
            r.append((t,o,fixed))
        g.append(r)
    return g
def fmt(g):
    return [" ".join(t+str(o)+('!' if f and t not in ALWAYS_FIXED else '') for t,o,f in row) for row in g]
def mask(c): return rot(BASE[c[0]],c[1])
def find(g,ch):
    for r,row in enumerate(g):
        for c,t in enumerate(row):
            if t[0]==ch: return (r,c)
def solved(g):
    """Independent BFS validator: reciprocal ports only."""
    R,C=len(g),len(g[0]); s=find(g,'O'); t=find(g,'G')
    seen={s}; q=[s]
    while q:
        r,c=q.pop(); m=mask(g[r][c])
        if (r,c)==t: return True
        for d,dr,dc in DIRS:
            if m&d:
                nr,nc=r+dr,c+dc
                if 0<=nr<R and 0<=nc<C and (nr,nc) not in seen and g[nr][nc][0] not in '#.' and mask(g[nr][nc])&OPP[d]:
                    seen.add((nr,nc)); q.append((nr,nc))
    return False
def options(c):
    t,o,f=c
    if f: return [(rot(BASE[t],o),0,o)]
    best={}
    for k in range(4):
        no=(o+k)%4; m=rot(BASE[t],no)
        if m not in best or best[m][0]>k: best[m]=(k,no)
    return [(m,k,no) for m,(k,no) in best.items()]
class Overflow(Exception): pass
def solve(g,cap=400000):
    """Exhaustive min-move search over simple source->target paths. Returns (moves, solution grid) or None."""
    R,C=len(g),len(g[0]); s=find(g,'O'); t=find(g,'G')
    opts=[[options(g[r][c]) if g[r][c][0] not in '#.' else [] for c in range(C)] for r in range(R)]
    best=[10**9,None]; nodes=[0]
    def dfs(cell,back,vis,cost,chosen):
        nodes[0]+=1
        if nodes[0]>cap: raise Overflow
        r,c=cell
        for m,k,no in opts[r][c]:
            if back and not (m&back): continue
            nc=cost+k
            if nc>=best[0]: continue
            if cell==t:
                best[0]=nc; best[1]=chosen+[(cell,no)]; continue
            if cell==s and False: pass
            for d,dr,dc in DIRS:
                if (m&d) and d!=back:
                    nr,ncc=r+dr,c+dc
                    if 0<=nr<R and 0<=ncc<C and (nr,ncc) not in vis and opts[nr][ncc]:
                        dfs((nr,ncc),OPP[d],vis|{(nr,ncc)},nc,chosen+[(cell,no)])
    dfs(s,0,{s},0,[])
    if best[1] is None: return None
    sol=[list(row) for row in g]
    for (r,c),no in best[1]:
        sol[r][c]=(g[r][c][0],no,g[r][c][2])
    sol=[[tuple(x) for x in row] for row in sol]
    assert solved(sol)
    return best[0],sol
def self_avoiding(R,C,s,t,blocked,minlen,maxlen,rng):
    path=[s]; vis={s}; steps=[0]
    def rec():
        steps[0]+=1
        if steps[0]>20000: return False
        cur=path[-1]
        if cur==t: return len(path)>=minlen
        if len(path)>=maxlen: return False
        ds=DIRS[:]; rng.shuffle(ds)
        for d,dr,dc in ds:
            n=(cur[0]+dr,cur[1]+dc)
            if 0<=n[0]<R and 0<=n[1]<C and n not in vis and n not in blocked:
                if n==t or True:
                    path.append(n); vis.add(n)
                    if rec(): return True
                    path.pop(); vis.discard(n)
        return False
    return list(path) if rec() else None
def dir_between(a,b):
    for d,dr,dc in DIRS:
        if (a[0]+dr,a[1]+dc)==b: return d
def orient_for(base_t,need,rng,allow_any=True):
    cands=[o for o in range(4) if rot(BASE[base_t],o)&need==need]
    return rng.choice(cands)
CHAPTERS=[ # (rows,cols) schedule, path types, tee p, cross p, blocked range, minlen frac, decoy types
 dict(sizes=[(4,4)]*20, tee=0.0,cross=0.0,blocked=(0,0),minlen=(4,8),decoy='IL',fixed=0.0),
 dict(sizes=[(4,4)]*6+[(4,5)]*6+[(5,5)]*8, tee=0.35,cross=0.12,blocked=(0,1),minlen=(6,10),decoy='ILTX',fixed=0.0),
 dict(sizes=[(5,5)]*14+[(5,6)]*6, tee=0.3,cross=0.1,blocked=(2,6),minlen=(8,13),decoy='ILTX',fixed=0.04),
 dict(sizes=[(5,5)]*6+[(5,6)]*8+[(6,6)]*6, tee=0.4,cross=0.15,blocked=(3,7),minlen=(10,16),decoy='ILTX',fixed=0.08),
 dict(sizes=[(5,6)]*6+[(6,6)]*14, tee=0.4,cross=0.2,blocked=(4,9),minlen=(12,19),decoy='ILTX',fixed=0.1),
]
def build(level_id,chap,idx,rng):
    cfg=CHAPTERS[chap-1]; R,C=cfg['sizes'][idx]; f=idx/19
    for attempt in range(400):
        minlen=int(cfg['minlen'][0]+(cfg['minlen'][1]-cfg['minlen'][0])*f)
        minlen=min(minlen,R*C-3 if cfg['blocked'][1]==0 else R*C-cfg['blocked'][1]-4)
        sr=rng.randrange(R); tr=rng.randrange(R); s=(sr,0); t=(tr,C-1)
        nb=int(round(cfg['blocked'][0]+(cfg['blocked'][1]-cfg['blocked'][0])*f))
        nb=max(0,nb+rng.choice([-1,0,0,1])) if cfg['blocked'][1] else 0
        # blocked cells first (random, never on s/t), then path around them
        cells=[(r,c) for r in range(R) for c in range(C) if (r,c) not in (s,t)]
        blocked=set(rng.sample(cells,nb))
        path=self_avoiding(R,C,s,t,blocked,minlen,minlen+4+int(4*f),rng)
        if not path: continue
        grid=[[None]*C for _ in range(R)]
        pset=set(path)
        for i,cell in enumerate(path):
            r,c=cell
            if i==0:
                o=orient_for('O',dir_between(cell,path[1]),rng); grid[r][c]=('O',o,True)
            elif i==len(path)-1:
                o=orient_for('G',dir_between(cell,path[-2]),rng); grid[r][c]=('G',o,True)
            else:
                a,b=dir_between(cell,path[i-1]),dir_between(cell,path[i+1])
                need=a|b; straight = OPP[a]==b
                x=rng.random()
                tp=('X' if x<cfg['cross'] else 'T' if x<cfg['cross']+cfg['tee'] else ('I' if straight else 'L'))
                sol_o=orient_for(tp,need,rng)
                # scramble: any orientation different from a valid one where possible
                start=rng.randrange(4)
                grid[r][c]=(tp,start,False)
        for r in range(R):
            for c in range(C):
                if (r,c) in blocked: grid[r][c]=('#',0,True)
                elif grid[r][c] is None:
                    if cfg['decoy'] and rng.random()<0.08 and chap==1: grid[r][c]=('.',0,True)
                    else:
                        tp=rng.choice(cfg['decoy']); grid[r][c]=(tp,rng.randrange(4),rng.random()<cfg['fixed'])
        if solved(grid): continue
        try: res=solve(grid)
        except Overflow: continue
        if not res: continue
        moves,sol=res
        if moves<max(2,idx//4+1+chap): continue
        # reject if some junction/other cells already provide a nearly-trivial solution (kept by min moves above)
        n_rot=sum(1 for row in grid for t_,o,fx in row if not fx)
        junc=sum(1 for row in grid for t_,o,fx in row if t_ in 'TX')
        diff=round(1+9*(level_id-1)/99)
        return dict(id=level_id,chapter=chap,rows=R,cols=C,source=list(find(grid,'O')),target=list(find(grid,'G')),
                    tiles=fmt(grid),solution=fmt(sol),par=moves,difficulty=diff,
                    rule="path",meta=dict(rotatable=n_rot,junctions=junc,obstacles=len(blocked),pathLength=len(path)))
    raise RuntimeError(f"could not build level {level_id}")
def main():
    out=sys.argv[1] if len(sys.argv)>1 else os.path.join(os.path.dirname(__file__),'..','app','src','main','assets','levels.json')
    levels=[]; lid=1
    for chap in range(1,6):
        for idx in range(20):
            rng=random.Random(1000*chap+idx*7+13)
            levels.append(build(lid,chap,idx,rng)); lid+=1
    # re-verify from serialized form
    for lv in levels:
        g=parse(lv['tiles']); sol=parse(lv['solution'])
        assert not solved(g) and solved(sol)
        r=solve(g); assert r and r[0]==lv['par']
    json.dump(dict(version=1,levels=levels),open(out,'w'),separators=(',',':'))
    pars=[l['par'] for l in levels]
    print("levels",len(levels),"par min/avg/max",min(pars),sum(pars)/len(pars),max(pars))
if __name__=='__main__': main()
