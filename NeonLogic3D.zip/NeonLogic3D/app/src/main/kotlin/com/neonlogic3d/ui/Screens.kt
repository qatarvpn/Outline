package com.neonlogic3d.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.neonlogic3d.data.persistence.*
import com.neonlogic3d.domain.model.Dir
import kotlinx.coroutines.delay

private val chapterNames = listOf("Fundamentals", "Junctions", "Obstacles", "Advanced Logic", "Master Challenges")
private fun chapterFirst(ch: Int) = (ch - 1) * 20 + 1

@Composable fun Logo(big: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        if (big) Canvas(Modifier.size(96.dp)) {
            val c = Offset(size.width / 2, size.height / 2); val r = size.minDimension * 0.45f
            val pts = (0 until 6).map { i -> val a = Math.toRadians(30.0 + 60 * i); Offset(c.x + r * Math.cos(a).toFloat(), c.y + r * Math.sin(a).toFloat()) }
            val p = Path().apply { moveTo(pts[0].x, pts[0].y); pts.drop(1).forEach { lineTo(it.x, it.y) }; close() }
            drawPath(p, NeonColors.Cyan, style = Stroke(6f))
            drawLine(NeonColors.Cyan, c, pts[1], 5f); drawLine(NeonColors.Cyan, c, pts[3], 5f); drawLine(NeonColors.Cyan, c, pts[5], 5f)
        }
        Text("NEON", color = NeonColors.Cyan, fontSize = if (big) 54.sp else 36.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
        Text("LOGIC 3D", color = Color.White, fontSize = if (big) 34.sp else 24.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
    }
}

@Composable fun SplashScreen(ready: Boolean, error: String?, onDone: () -> Unit) {
    var elapsed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(1600); elapsed = true }
    LaunchedEffect(ready, elapsed) { if (ready && elapsed) onDone() }
    val infinite = rememberInfiniteTransition(label = "load"); val p by infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(1400), RepeatMode.Restart), label = "p")
    ScreenBackground {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Logo(true); Spacer(Modifier.height(48.dp))
            LinearProgressIndicator(progress = { if (ready) 1f else p }, modifier = Modifier.width(240.dp).height(6.dp).clip(RoundedCornerShape(3.dp)), color = NeonColors.Cyan, trackColor = NeonColors.Locked)
            Spacer(Modifier.height(8.dp)); Text(error ?: "Loading…", color = if (error != null) NeonColors.Danger else NeonColors.Muted, fontSize = 13.sp)
        }
    }
}

@Composable fun MenuScreen(vm: AppViewModel, progress: Progress, settings: Settings) {
    val hasProgress = progress.completedCount > 0 || progress.saved != null
    Box(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.align(Alignment.TopEnd).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RoundIcon(if (settings.sfxOn) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff, if (settings.sfxOn) "Sound on" else "Sound off", { vm.updateSettings { it.copy(sfxOn = !it.sfxOn) } })
            RoundIcon(Icons.Filled.MusicNote, if (settings.musicOn) "Music on" else "Music off", { vm.updateSettings { it.copy(musicOn = !it.musicOn) } },
                tint = if (settings.musicOn) Color.White else NeonColors.Muted.copy(alpha = 0.5f))
        }
        Box(Modifier.align(Alignment.TopStart).padding(start = 20.dp, top = 24.dp)) { Logo(false) }
        Column(Modifier.align(Alignment.BottomCenter).padding(horizontal = 24.dp, vertical = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            NeonButton(if (hasProgress) "Play / Continue" else "Play", { vm.continueGame() }, Modifier.fillMaxWidth(), NeonColors.Green, Icons.Filled.PlayArrow)
            NeonButton("Level Selection", { vm.go(Screen.Levels(((progress.currentLevel - 1) / 20 + 1).coerceIn(1, 5))) }, Modifier.fillMaxWidth(), NeonColors.Blue, Icons.Filled.Home)
            NeonButton("Daily Puzzle", { vm.go(Screen.Daily) }, Modifier.fillMaxWidth(), NeonColors.Blue, Icons.Filled.CalendarMonth)
            NeonButton("Settings", { vm.go(Screen.Settings) }, Modifier.fillMaxWidth(), NeonColors.Blue, Icons.Filled.Settings)
            GlassPanel(Modifier.fillMaxWidth()) {
                val pct = progress.completedCount * 100 / LEVEL_COUNT
                Row(Modifier.fillMaxWidth()) { Text("Progress", color = NeonColors.Muted, fontSize = 13.sp); Spacer(Modifier.weight(1f)); Text("$pct%", color = NeonColors.Text, fontSize = 13.sp) }
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(progress = { progress.completedCount / LEVEL_COUNT.toFloat() }, Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)), NeonColors.Cyan, NeonColors.Locked)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Star, null, tint = NeonColors.Amber, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(6.dp))
                    Text("Levels", color = NeonColors.Text); Spacer(Modifier.weight(1f)); Text("${progress.completedCount}/$LEVEL_COUNT", color = NeonColors.Text, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable fun ChaptersScreen(vm: AppViewModel, progress: Progress) {
    ScreenBackground {
        Column(Modifier.fillMaxSize()) {
            TopBar("Chapters", { vm.go(Screen.Menu) })
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for (ch in 1..5) {
                    val ids = chapterFirst(ch)..(chapterFirst(ch) + 19); val done = ids.count { it in progress.stars }; val unlocked = progress.highestUnlocked >= chapterFirst(ch)
                    GlassPanel(Modifier.fillMaxWidth().clickable(enabled = unlocked) { vm.go(Screen.Levels(ch)) }.semantics { contentDescription = "Chapter $ch ${chapterNames[ch - 1]}, $done of 20 completed" + if (unlocked) "" else ", locked" }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("$ch", color = NeonColors.Cyan, fontSize = 26.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) { Text(chapterNames[ch - 1], color = NeonColors.Text, fontWeight = FontWeight.SemiBold, fontSize = 17.sp); Text("$done/20", color = NeonColors.Muted, fontSize = 13.sp) }
                            if (!unlocked) Icon(Icons.Filled.Lock, null, tint = NeonColors.Muted)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                val total = progress.completedCount
                Row { Text("Total Progress", color = NeonColors.Muted); Spacer(Modifier.weight(1f)); Text("$total/$LEVEL_COUNT", color = NeonColors.Text) }
                LinearProgressIndicator(progress = { total / LEVEL_COUNT.toFloat() }, Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)), NeonColors.Cyan, NeonColors.Locked)
            }
        }
    }
}

@Composable fun LevelsScreen(vm: AppViewModel, progress: Progress, chapter: Int) {
    ScreenBackground {
        Column(Modifier.fillMaxSize()) {
            TopBar("Level Selection", { vm.go(Screen.Menu) }) { IconButton(onClick = { vm.go(Screen.Chapters) }) { Icon(Icons.Filled.GridView, "Chapters", tint = Color.White) } }
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items((1..5).toList()) { ch ->
                    val sel = ch == chapter; val unlocked = progress.highestUnlocked >= chapterFirst(ch)
                    Box(Modifier.heightIn(min = 48.dp).clip(RoundedCornerShape(12.dp)).background(if (sel) NeonColors.Blue.copy(alpha = 0.35f) else NeonColors.Panel)
                        .border(if (sel) 2.dp else 1.dp, if (sel) NeonColors.Cyan else NeonColors.Border, RoundedCornerShape(12.dp))
                        .clickable(enabled = unlocked) { vm.go(Screen.Levels(ch)) }.padding(horizontal = 16.dp), contentAlignment = Alignment.Center) {
                        Text("Chapter $ch" + if (!unlocked) " 🔒" else "", color = if (unlocked) NeonColors.Text else NeonColors.Muted, fontSize = 14.sp)
                    }
                }
            }
            Text(chapterNames[chapter - 1], Modifier.padding(16.dp, 12.dp, 16.dp, 4.dp), color = NeonColors.Muted, fontSize = 14.sp)
            LazyVerticalGrid(GridCells.Fixed(4), Modifier.weight(1f), contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items((chapterFirst(chapter)..chapterFirst(chapter) + 19).toList()) { id ->
                    val stars = progress.stars[id]; val unlocked = id <= progress.highestUnlocked
                    val shape = RoundedCornerShape(12.dp)
                    Box(Modifier.aspectRatio(1f).clip(shape).background(if (unlocked) NeonColors.Panel else NeonColors.Locked.copy(alpha = 0.6f))
                        .border(if (stars != null) 2.dp else 1.dp, if (stars != null) NeonColors.Cyan else NeonColors.Border.copy(alpha = if (unlocked) 1f else 0.3f), shape)
                        .clickable(enabled = unlocked) { vm.startLevel(id) }
                        .semantics { contentDescription = "Level $id, " + when { stars != null -> "completed, $stars stars"; unlocked -> "unlocked"; else -> "locked" } },
                        contentAlignment = Alignment.Center) {
                        if (unlocked) Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$id", color = NeonColors.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            if (stars != null) Stars(stars, 14)
                        } else Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$id", color = NeonColors.Muted, fontSize = 17.sp); Icon(Icons.Filled.Lock, null, tint = NeonColors.Muted, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable fun DailyScreen(vm: AppViewModel, progress: Progress) {
    val today = todayEpochDay(); val done = progress.dailyDoneDay == today
    ScreenBackground {
        Column(Modifier.fillMaxSize()) {
            TopBar("Daily Puzzle", { vm.go(Screen.Menu) })
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(24.dp)); Logo(true)
                GlassPanel(Modifier.fillMaxWidth()) {
                    Text("Today's Puzzle", color = NeonColors.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                    Text(if (done) "Completed today ✓ — a new puzzle arrives tomorrow." else "A fresh puzzle every day. Daily play does not change level progression.",
                        color = NeonColors.Muted, fontSize = 14.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), textAlign = TextAlign.Center)
                    NeonButton(if (done) "Play again" else "Play", { vm.startDaily() }, Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable fun SettingsScreen(vm: AppViewModel, s: Settings) {
    var confirm by remember { mutableStateOf(false) }
    ScreenBackground {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            TopBar("Settings", { vm.go(Screen.Menu) })
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                GlassPanel(Modifier.fillMaxWidth()) {
                    Text("Audio", color = NeonColors.Cyan, fontWeight = FontWeight.SemiBold)
                    LabeledSlider("Music", s.music) { v -> vm.updateSettings { it.copy(music = v) } }
                    LabeledSlider("Sound Effects", s.sfx) { v -> vm.updateSettings { it.copy(sfx = v) } }
                    SwitchRow("Haptic Feedback", s.haptics) { v -> vm.updateSettings { it.copy(haptics = v) } }
                }
                GlassPanel(Modifier.fillMaxWidth()) {
                    Text("Graphics Quality", color = NeonColors.Text, fontWeight = FontWeight.SemiBold)
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GraphicsQuality.entries.forEach { q ->
                            val sel = q == s.quality
                            Box(Modifier.weight(1f).heightIn(min = 48.dp).clip(RoundedCornerShape(10.dp)).background(if (sel) NeonColors.Blue else NeonColors.Locked)
                                .border(if (sel) 2.dp else 1.dp, if (sel) NeonColors.Cyan else NeonColors.Border, RoundedCornerShape(10.dp))
                                .clickable { vm.updateSettings { it.copy(quality = q) } }, contentAlignment = Alignment.Center) {
                                Text(q.name.lowercase().replaceFirstChar { it.uppercase() } + if (sel) " ✓" else "", color = Color.White, fontSize = 14.sp)
                            }
                        }
                    }
                    LabeledSlider("Camera Sensitivity", s.camSensitivity) { v -> vm.updateSettings { it.copy(camSensitivity = v) } }
                }
                NeonButton("Replay Tutorial", { vm.go(Screen.Tutorial) }, Modifier.fillMaxWidth(), NeonColors.Blue, Icons.Filled.School)
                NeonButton("Reset Progress", { confirm = true }, Modifier.fillMaxWidth(), NeonColors.Danger, Icons.Filled.Warning)
                Text("This will delete all your progress. Are you sure?", color = NeonColors.Muted, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, title = { Text("Reset progress?") },
        text = { Text("All completed levels, stars, best scores and saved puzzles will be permanently deleted. Settings are kept.") },
        confirmButton = { TextButton(onClick = { vm.resetProgress(); confirm = false }) { Text("Delete progress", color = NeonColors.Danger) } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } })
}

@Composable fun LabeledSlider(label: String, value: Float, onChange: (Float) -> Unit) {
    var local by remember(value) { mutableFloatStateOf(value) }
    Column(Modifier.padding(top = 8.dp)) {
        Row { Text(label, color = NeonColors.Text, fontSize = 14.sp); Spacer(Modifier.weight(1f)); Text("${(local * 100).toInt()}%", color = NeonColors.Muted, fontSize = 13.sp) }
        Slider(local, { local = it }, onValueChangeFinished = { onChange(local) }, modifier = Modifier.semantics { contentDescription = "$label ${(local * 100).toInt()} percent" })
    }
}
@Composable fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = NeonColors.Text, fontSize = 14.sp); Spacer(Modifier.weight(1f)); Switch(checked, onChange)
    }
}

@Composable fun TutorialScreen(vm: AppViewModel) {
    val pages = listOf(
        Triple("Tap a tile to rotate it 90°", Dir.N or Dir.E, "Every tap turns one tile a quarter turn clockwise and counts as one move."),
        Triple("Connect source to target", Dir.E or Dir.W, "Build one continuous path from the cyan source to the amber target."),
        Triple("Ports must match", Dir.N or Dir.S, "Two tiles connect only when BOTH have a port facing each other. Touching is not enough."),
        Triple("Junctions", 15, "T and four-way tiles open more sides. Extra branches are allowed, but blocked cells never connect."),
        Triple("Fewer moves, more stars", Dir.N or Dir.E or Dir.W, "Finish within par for three stars. Using a hint caps your rating at two stars.")
    )
    var page by remember { mutableIntStateOf(0) }
    ScreenBackground {
        Column(Modifier.fillMaxSize()) {
            TopBar("Tutorial", { vm.go(Screen.Menu) }) { Text("${page + 1}/5", color = NeonColors.Muted, fontSize = 13.sp) }
            Column(Modifier.weight(1f).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                val (title, mask, body) = pages[page]
                TileGlyph(mask, size = 140); Spacer(Modifier.height(28.dp))
                Text(title, color = NeonColors.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(10.dp)); Text(body, color = NeonColors.Muted, fontSize = 16.sp, textAlign = TextAlign.Center)
            }
            NeonButton(if (page < 4) "Next" else "Play Level 1", { if (page < 4) page++ else { vm.markTutorialSeen(); vm.startLevel(1, coach = true) } }, Modifier.fillMaxWidth().padding(20.dp))
        }
    }
}
