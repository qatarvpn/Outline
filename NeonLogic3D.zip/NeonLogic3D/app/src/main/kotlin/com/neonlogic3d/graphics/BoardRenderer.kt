package com.neonlogic3d.graphics

import android.view.Choreographer
import android.view.SurfaceView
import com.google.android.filament.*
import com.google.android.filament.android.UiHelper
import com.google.android.filament.filamat.MaterialBuilder
import com.neonlogic3d.data.persistence.GraphicsQuality
import com.neonlogic3d.domain.model.*
import com.neonlogic3d.domain.puzzle.PuzzleState
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/**
 * Filament renderer. It only DISPLAYS the authoritative [PuzzleState]; it never decides connectivity.
 * All methods must be called on the main thread.
 */
class BoardRenderer(private var quality: GraphicsQuality) : Choreographer.FrameCallback {
    companion object {
        init { Filament.init() }
        private const val TOP = 0.22f
        private val PALETTE = arrayOf(
            floatArrayOf(0.10f, 0.80f, 1.00f), floatArrayOf(0.35f, 0.50f, 1.00f), floatArrayOf(1.00f, 0.60f, 0.10f),
            floatArrayOf(0.30f, 1.00f, 0.40f), floatArrayOf(0.90f, 0.30f, 1.00f)
        )
        private val AMBER = floatArrayOf(1.0f, 0.70f, 0.15f)
        private const val MATERIAL_CODE = """
            void material(inout MaterialInputs material) {
                prepareMaterial(material);
                material.baseColor = materialParams.baseColor;
                material.metallic = materialParams.mr.x;
                material.roughness = materialParams.mr.y;
                material.emissive = materialParams.emissiveColor;
            }"""
    }

    private class Part(val entity: Int, val lx: Float, val ly: Float, val lz: Float, val sx: Float, val sy: Float, val sz: Float)
    private class CellVis(
        val pos: Pos, val parts: List<Part>, val arms: List<Part>, val slabMi: MaterialInstance?, val armMi: MaterialInstance?,
        val px: Float, val pz: Float, val isSource: Boolean, val isTarget: Boolean, val rotatable: Boolean
    ) { var angle = 0f; var target = 0f; var pop = 0f; var hint = 0f; var lastOrientation = 0; var py = 0f }

    private val engine: Engine = Engine.create()
    private val renderer: Renderer = engine.createRenderer()
    private val scene: Scene = engine.createScene()
    private val view: View = engine.createView()
    private val cameraEntity = EntityManager.get().create()
    private val camera: Camera = engine.createCamera(cameraEntity)
    private val sunEntity = EntityManager.get().create()
    private var skybox: Skybox? = null
    private var indirect: IndirectLight? = null
    private lateinit var material: Material
    private lateinit var vb: VertexBuffer
    private lateinit var ib: IndexBuffer
    private val loose = ArrayList<Pair<Int, MaterialInstance>>() // platform pieces
    private val looseMis = ArrayList<MaterialInstance>()
    private var cells: List<CellVis> = emptyList()
    private var cellEntities = ArrayList<Int>()
    private var cellMis = ArrayList<MaterialInstance>()

    private var uiHelper: UiHelper? = null
    private var swapChain: SwapChain? = null
    private val choreographer = Choreographer.getInstance()
    private var running = false
    private var lastFrameNs = 0L
    private var vw = 1; private var vh = 1

    // game-visible state
    private var loadedLevel = -1
    private var rows = 4; private var cols = 4; private var chapter = 1
    private var reached: Set<Pos> = emptySet(); private var path: List<Pos> = emptyList()
    private var completedAt = -1f; private var time = 0f
    var paused = false
    /** When false no frames are rendered (screens that fully cover the 3D view). */
    var renderEnabled = true
    /** Menu background: slow camera sweep and a looping energy-flow celebration. */
    var demo = false
    var yaw = 0f; private set
    var onCelebrationFinished: (() -> Unit)? = null
    private var celebrationSent = false
    /** True while any tile is mid-rotation; the UI ignores taps then (conflicting-animation rule). */
    val isBusy: Boolean get() = cells.any { abs(it.target - it.angle) > 0.002f }

    init {
        buildMaterial(); buildCubeMesh()
        view.scene = scene; view.camera = camera
        camera.setExposure(1.0f)
        skybox = Skybox.Builder().color(0.015f, 0.03f, 0.075f, 1f).build(engine); scene.skybox = skybox
        indirect = IndirectLight.Builder().irradiance(1, floatArrayOf(0.55f, 0.65f, 0.9f)).intensity(1.6f).build(engine); scene.indirectLight = indirect
        LightManager.Builder(LightManager.Type.DIRECTIONAL).color(1f, 0.96f, 0.9f).intensity(3.0f)
            .direction(-0.35f, -1f, -0.55f).castShadows(quality != GraphicsQuality.LOW).build(engine, sunEntity)
        scene.addEntity(sunEntity)
        view.antiAliasing = View.AntiAliasing.FXAA
        applyQuality(quality)
        buildPlatform()
    }

    /** Graphics quality can change at runtime from Settings. */
    fun applyQuality(q: GraphicsQuality) {
        quality = q
        val lm = engine.lightManager; lm.setShadowCaster(lm.getInstance(sunEntity), q != GraphicsQuality.LOW)
        view.multiSampleAntiAliasingOptions = View.MultiSampleAntiAliasingOptions().also { it.enabled = q == GraphicsQuality.HIGH }
        view.bloomOptions = View.BloomOptions().also { it.enabled = q != GraphicsQuality.LOW; it.strength = 0.22f; it.levels = 5 }
        view.isPostProcessingEnabled = q != GraphicsQuality.LOW
    }

    // ---------- setup ----------
    private fun buildMaterial() {
        MaterialBuilder.init()
        try {
            val pkg = MaterialBuilder()
                .platform(MaterialBuilder.Platform.MOBILE).targetApi(MaterialBuilder.TargetApi.OPENGL)
                .optimization(MaterialBuilder.Optimization.PERFORMANCE).name("neon")
                .shading(MaterialBuilder.Shading.LIT)
                .uniformParameter(MaterialBuilder.UniformType.FLOAT4, "baseColor")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT4, "emissiveColor")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT2, "mr")
                .material(MATERIAL_CODE).build(engine)
            check(pkg.isValid) { "material compilation failed" }
            material = Material.Builder().payload(pkg.buffer, pkg.buffer.remaining()).build(engine)
        } finally { MaterialBuilder.shutdown() }
    }

    private fun buildCubeMesh() {
        // 6 faces x 4 verts; layout: float3 position + short4 tangent-frame quaternion (SNORM) = 20 bytes
        val normals = arrayOf(floatArrayOf(1f, 0f, 0f), floatArrayOf(-1f, 0f, 0f), floatArrayOf(0f, 1f, 0f),
            floatArrayOf(0f, -1f, 0f), floatArrayOf(0f, 0f, 1f), floatArrayOf(0f, 0f, -1f))
        val data = ByteBuffer.allocateDirect(24 * 20).order(ByteOrder.nativeOrder())
        val idx = ByteBuffer.allocateDirect(36 * 2).order(ByteOrder.nativeOrder())
        for ((f, n) in normals.withIndex()) {
            val t = if (abs(n[1]) > 0.5f) floatArrayOf(1f, 0f, 0f) else floatArrayOf(0f, 1f, 0f)
            val b = floatArrayOf(n[1] * t[2] - n[2] * t[1], n[2] * t[0] - n[0] * t[2], n[0] * t[1] - n[1] * t[0])
            val q = quatFromFrame(t, b, n)
            val u = t; val v = b
            val corners = arrayOf(-1 to -1, 1 to -1, 1 to 1, -1 to 1)
            for ((a, c) in corners) {
                val p = FloatArray(3) { 0.5f * n[it] + 0.5f * a * u[it] + 0.5f * c * v[it] }
                data.putFloat(p[0]).putFloat(p[1]).putFloat(p[2])
                for (k in 0..3) data.putShort((q[k] * 32767f).roundToInt().toShort())
            }
            val o = (f * 4).toShort()
            // winding chosen so that (u x v) == n gives counter-clockwise seen from outside
            for (i in shortArrayOf(0, 1, 2, 0, 2, 3)) idx.putShort((o + i).toShort())
        }
        data.flip(); idx.flip()
        vb = VertexBuffer.Builder().bufferCount(1).vertexCount(24)
            .attribute(VertexBuffer.VertexAttribute.POSITION, 0, VertexBuffer.AttributeType.FLOAT3, 0, 20)
            .attribute(VertexBuffer.VertexAttribute.TANGENTS, 0, VertexBuffer.AttributeType.SHORT4, 12, 20)
            .normalized(VertexBuffer.VertexAttribute.TANGENTS).build(engine)
        vb.setBufferAt(engine, 0, data)
        ib = IndexBuffer.Builder().indexCount(36).bufferType(IndexBuffer.Builder.IndexType.USHORT).build(engine)
        ib.setBuffer(engine, idx)
    }

    /** Rotation matrix with columns (t, b, n) -> unit quaternion (x,y,z,w) with w > 0 as Filament expects. */
    private fun quatFromFrame(t: FloatArray, b: FloatArray, n: FloatArray): FloatArray {
        val m00 = t[0]; val m10 = t[1]; val m20 = t[2]; val m01 = b[0]; val m11 = b[1]; val m21 = b[2]
        val m02 = n[0]; val m12 = n[1]; val m22 = n[2]
        val tr = m00 + m11 + m22
        var x: Float; var y: Float; var z: Float; var w: Float
        if (tr > 0f) { val s = 0.5f / sqrt(tr + 1f); w = 0.25f / s; x = (m21 - m12) * s; y = (m02 - m20) * s; z = (m10 - m01) * s }
        else if (m00 > m11 && m00 > m22) { val s = 2f * sqrt(1f + m00 - m11 - m22); w = (m21 - m12) / s; x = 0.25f * s; y = (m01 + m10) / s; z = (m02 + m20) / s }
        else if (m11 > m22) { val s = 2f * sqrt(1f + m11 - m00 - m22); w = (m02 - m20) / s; x = (m01 + m10) / s; y = 0.25f * s; z = (m12 + m21) / s }
        else { val s = 2f * sqrt(1f + m22 - m00 - m11); w = (m10 - m01) / s; x = (m02 + m20) / s; y = (m12 + m21) / s; z = 0.25f * s }
        if (w < 0f) { x = -x; y = -y; z = -z; w = -w }
        if (w < 0.01f) w = 0.01f
        val len = sqrt(x * x + y * y + z * z + w * w)
        return floatArrayOf(x / len, y / len, z / len, w / len)
    }

    private fun newMi(r: Float, g: Float, b: Float, metal: Float, rough: Float, er: Float = 0f, eg: Float = 0f, eb: Float = 0f, ei: Float = 0f): MaterialInstance {
        val mi = material.createInstance()
        mi.setParameter("baseColor", r, g, b, 1f); mi.setParameter("mr", metal, rough); mi.setParameter("emissiveColor", er * ei, eg * ei, eb * ei, 3f)
        return mi
    }

    private fun addBox(mi: MaterialInstance, shadows: Boolean): Int {
        val e = EntityManager.get().create()
        RenderableManager.Builder(1).boundingBox(Box(0f, 0f, 0f, 0.5f, 0.5f, 0.5f))
            .geometry(0, RenderableManager.PrimitiveType.TRIANGLES, vb, ib).material(0, mi)
            .castShadows(shadows).receiveShadows(true).build(engine, e)
        engine.transformManager.create(e); scene.addEntity(e); return e
    }

    private fun setBox(e: Int, px: Float, py: Float, pz: Float, ang: Float, p: Part) {
        val c = cos(ang); val s = sin(ang)
        val m = floatArrayOf(
            c * p.sx, 0f, -s * p.sx, 0f,
            0f, p.sy, 0f, 0f,
            s * p.sz, 0f, c * p.sz, 0f,
            px + c * p.lx + s * p.lz, py + p.ly, pz - s * p.lx + c * p.lz, 1f
        )
        val tm = engine.transformManager; tm.setTransform(tm.getInstance(e), m)
    }

    private fun buildPlatform() {
        val mi = newMi(0.05f, 0.06f, 0.08f, 0.6f, 0.5f); looseMis.add(mi)
        val rim = newMi(0.02f, 0.05f, 0.08f, 0f, 0.6f, 0.1f, 0.8f, 1f, 0.5f); looseMis.add(rim)
        loose.add(addBox(mi, false) to mi); loose.add(addBox(rim, false) to rim)
    }

    private fun placePlatform() {
        val (slab, _) = loose[0]; val (rim, _) = loose[1]
        val w = cols + 1.4f; val d = rows + 1.4f
        setBox(slab, 0f, -0.42f, 0f, 0f, Part(slab, 0f, 0f, 0f, w, 0.3f, d))
        setBox(rim, 0f, -0.58f, 0f, 0f, Part(rim, 0f, 0f, 0f, w + 0.12f, 0.06f, d + 0.12f))
    }

    // ---------- level / state ----------
    private fun clearCells() {
        for (e in cellEntities) { scene.removeEntity(e); engine.destroyEntity(e); EntityManager.get().destroy(e) }
        for (mi in cellMis) engine.destroyMaterialInstance(mi)
        cellEntities.clear(); cellMis.clear(); cells = emptyList()
    }

    private fun buildLevel(s: PuzzleState) {
        clearCells()
        val b = s.board; rows = b.rows; cols = b.cols; chapter = s.level.chapter.coerceIn(1, 5); loadedLevel = s.level.id
        val list = ArrayList<CellVis>()
        val accent = PALETTE[chapter - 1]
        for (r in 0 until rows) for (c in 0 until cols) {
            val t = b[r, c]; val parts = ArrayList<Part>(); val arms = ArrayList<Part>()
            val px = c - (cols - 1) / 2f; val pz = r - (rows - 1) / 2f
            val slabMi = newMi(0.17f, 0.19f, 0.24f, 0.35f, 0.42f).also { cellMis.add(it) }
            val armMi = newMi(0.02f, 0.05f, 0.07f, 0f, 0.5f, accent[0], accent[1], accent[2], 0.25f).also { cellMis.add(it) }
            val h = if (t.type == TileType.BLOCKED) 0.7f else if (t.type == TileType.EMPTY) 0.3f else 0.44f
            val slabE = addBox(slabMi, true).also { cellEntities.add(it) }
            val slab = Part(slabE, 0f, if (t.type == TileType.BLOCKED) 0.13f else 0f, 0f, 0.94f, h, 0.94f); parts.add(slab)
            if (t.type.connectable) {
                val hubSize = if (t.type == TileType.SOURCE || t.type == TileType.TARGET) 0.42f else 0.22f
                val hubE = addBox(armMi, false).also { cellEntities.add(it) }
                val hub = Part(hubE, 0f, TOP + 0.04f, 0f, hubSize, if (hubSize > 0.3f) 0.2f else 0.1f, hubSize); parts.add(hub); arms.add(hub)
                for (d in Dir.ALL) if (t.type.baseMask and d != 0) {
                    val e = addBox(armMi, false).also { cellEntities.add(it) }
                    val dx = if (d == Dir.E) 1f else if (d == Dir.W) -1f else 0f
                    val dz = if (d == Dir.S) 1f else if (d == Dir.N) -1f else 0f
                    val p = Part(e, dx * 0.25f, TOP + 0.04f, dz * 0.25f, if (dx != 0f) 0.5f else 0.13f, 0.08f, if (dz != 0f) 0.5f else 0.13f)
                    parts.add(p); arms.add(p)
                }
            }
            val cv = CellVis(Pos(r, c), parts, arms, slabMi, armMi, px, pz, t.type == TileType.SOURCE, t.type == TileType.TARGET, t.rotatable)
            cv.angle = t.orientation.toFloat(); cv.target = cv.angle; cv.lastOrientation = t.orientation
            list.add(cv)
        }
        cells = list; placePlatform(); completedAt = -1f; celebrationSent = false; time = 0f
        applyDerived(s); updateCamera(); refreshTransforms(true)
    }

    private fun applyDerived(s: PuzzleState) { reached = s.connection.reached; path = s.connection.path }

    /** Push the latest authoritative state. A new level id triggers a full rebuild; otherwise tiles animate to the new orientations. */
    fun submit(s: PuzzleState) {
        if (s.level.id != loadedLevel || s.board.rows != rows || s.board.cols != cols) { buildLevel(s); if (s.completed) completedAt = time; return }
        for (cv in cells) {
            val o = s.board[cv.pos].orientation; val d = (o - cv.lastOrientation + 4) % 4
            if (d != 0) { cv.target += if (d == 3) -1f else d.toFloat(); cv.lastOrientation = o }
        }
        applyDerived(s)
        if (s.completed && completedAt < 0f) { completedAt = time; celebrationSent = false }
        if (!s.completed) { completedAt = -1f }
    }

    fun pulse(p: Pos) { cells.firstOrNull { it.pos == p }?.pop = 1f }
    fun flashHint(p: Pos) { cells.firstOrNull { it.pos == p }?.hint = 2.5f }

    // ---------- camera & picking ----------
    private var camE = FloatArray(3); private var camF = FloatArray(3); private var camR = FloatArray(3); private var camU = FloatArray(3)
    private var tanV = tan(Math.toRadians(20.0)).toFloat(); private var aspect = 1f
    fun setCameraYaw(y: Float) { yaw = y.coerceIn(-0.6f, 0.6f); updateCamera() }

    private fun updateCamera() {
        aspect = vw.toFloat() / vh.coerceAtLeast(1)
        val fov = 40.0; val half = Math.toRadians(fov / 2)
        val radius = 0.5f * hypot(cols.toFloat(), rows.toFloat()) + 0.9f
        val sinH = sin(atan(tan(half) * aspect))
        val dist = (radius / min(sin(half), sinH)).toFloat() * 1.02f
        val pitch = Math.toRadians(52.0).toFloat()
        val tx = 0f; val ty = 0f; val tz = 0.35f
        val ex = tx + dist * sin(yaw) * cos(pitch); val ey = ty + dist * sin(pitch); val ez = tz + dist * cos(yaw) * cos(pitch)
        camera.setProjection(fov, aspect.toDouble(), 0.1, 100.0, Camera.Fov.VERTICAL)
        camera.lookAt(ex.toDouble(), ey.toDouble(), ez.toDouble(), tx.toDouble(), ty.toDouble(), tz.toDouble(), 0.0, 1.0, 0.0)
        camE = floatArrayOf(ex, ey, ez)
        var f = floatArrayOf(tx - ex, ty - ey, tz - ez); val fl = sqrt(f[0] * f[0] + f[1] * f[1] + f[2] * f[2]); f = floatArrayOf(f[0] / fl, f[1] / fl, f[2] / fl)
        var rr = floatArrayOf(f[1] * 0f - f[2] * 1f, f[2] * 0f - f[0] * 0f, f[0] * 1f - f[1] * 0f)
        val rl = sqrt(rr[0] * rr[0] + rr[1] * rr[1] + rr[2] * rr[2]); rr = floatArrayOf(rr[0] / rl, rr[1] / rl, rr[2] / rl)
        val u = floatArrayOf(rr[1] * f[2] - rr[2] * f[1], rr[2] * f[0] - rr[0] * f[2], rr[0] * f[1] - rr[1] * f[0])
        camF = f; camR = rr; camU = u; tanV = tan(half).toFloat()
    }

    /** Ray-cast from a screen point to the plane of the tile tops and return the logical cell, if any. */
    fun pickCell(sx: Float, sy: Float): Pos? {
        if (cells.isEmpty()) return null
        val nx = 2f * sx / vw - 1f; val ny = 1f - 2f * sy / vh
        val d = FloatArray(3) { camF[it] + camR[it] * nx * tanV * aspect + camU[it] * ny * tanV }
        if (d[1] >= -1e-5f) return null
        val t = (TOP - camE[1]) / d[1]
        val hx = camE[0] + d[0] * t; val hz = camE[2] + d[2] * t
        val c = floor(hx + cols / 2f).toInt(); val r = floor(hz + rows / 2f).toInt()
        return if (r in 0 until rows && c in 0 until cols) Pos(r, c) else null
    }

    // ---------- frame loop ----------
    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t.coerceIn(0f, 1f)

    private fun refreshTransforms(all: Boolean) {
        val tc = if (completedAt >= 0f) time - completedAt else -1f
        for (cv in cells) {
            val wave = if (tc in 0f..1.6f) 0.14f * sin(tc * 9f - (cv.pos.r + cv.pos.c) * 0.7f) * (1f - tc / 1.6f) else 0f
            val lift = (if (cv.pop > 0f) 0.10f * cv.pop else 0f) + wave
            val ang = -cv.angle * (Math.PI / 2).toFloat()
            for (p in cv.parts) setBox(p.entity, cv.px, lift, cv.pz, if (p.entity == cv.parts[0].entity) 0f else ang, p)
        }
    }

    private fun updateEmissives() {
        val acc = PALETTE[chapter - 1]
        val tc = if (completedAt >= 0f) time - completedAt else -1f
        val flowIdx = if (tc >= 0f && path.isNotEmpty()) tc * (path.size / 1.1f) else -1f
        for (cv in cells) {
            val a = cv.armMi ?: continue
            val on = cv.pos in reached
            var r = 0.10f; var g = 0.30f; var b = 0.40f; var k = 0.25f // dim = unpowered
            if (on) { r = acc[0]; g = acc[1]; b = acc[2]; k = 1.6f + 0.35f * sin(time * 5f - (cv.pos.r + cv.pos.c)) }
            if (cv.isSource) { r = 0.1f; g = 0.9f; b = 1f; k = 2.2f }
            if (cv.isTarget) { if (completedAt >= 0f && flowIdx >= path.size - 1) { r = AMBER[0]; g = AMBER[1]; b = AMBER[2]; k = 3.2f + sin(time * 10f) * 0.6f } else { r = AMBER[0]; g = AMBER[1]; b = AMBER[2]; k = 0.35f } }
            if (flowIdx >= 0f) { val i = path.indexOf(cv.pos); if (i in 0..flowIdx.toInt()) { r = lerp(acc[0], 1f, 0.5f); g = lerp(acc[1], 1f, 0.5f); b = lerp(acc[2], 1f, 0.5f); k = 3.0f } }
            if (cv.hint > 0f) { r = AMBER[0]; g = AMBER[1]; b = AMBER[2]; k = 1.5f + 1.5f * sin(time * 10f).absoluteValue }
            a.setParameter("emissiveColor", r * k, g * k, b * k, 3f)
            a.setParameter("baseColor", r * 0.35f * min(k, 1f), g * 0.35f * min(k, 1f), b * 0.35f * min(k, 1f), 1f)
        }
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        choreographer.postFrameCallback(this)
        val dt = if (lastFrameNs == 0L) 0f else ((frameTimeNanos - lastFrameNs) / 1e9f).coerceAtMost(0.05f)
        lastFrameNs = frameTimeNanos
        if (!paused) {
            time += dt
            if (demo) { setCameraYaw(0.4f * sin(time * 0.25f)); if (completedAt >= 0f && time - completedAt > 7f) { completedAt = time; celebrationSent = true } }
            for (cv in cells) {
                val d = cv.target - cv.angle
                if (abs(d) > 0.002f) { val step = max(abs(d) * 12f, 2.2f) * dt; cv.angle = if (step >= abs(d)) cv.target else cv.angle + sign(d) * step } else cv.angle = cv.target
                if (cv.pop > 0f) cv.pop = max(0f, cv.pop - dt * 4f)
                if (cv.hint > 0f) cv.hint = max(0f, cv.hint - dt)
            }
            if (completedAt >= 0f && !celebrationSent && time - completedAt > 2.1f) { celebrationSent = true; onCelebrationFinished?.invoke() }
        }
        refreshTransforms(false); updateEmissives()
        val sc = swapChain
        if (renderEnabled && uiHelper?.isReadyToRender == true && sc != null && renderer.beginFrame(sc, frameTimeNanos)) { renderer.render(view); renderer.endFrame() }
    }

    // ---------- lifecycle ----------
    fun attach(surfaceView: SurfaceView) {
        val helper = UiHelper(UiHelper.ContextErrorPolicy.DONT_CHECK)
        helper.renderCallback = object : UiHelper.RendererCallback {
            override fun onNativeWindowChanged(surface: android.view.Surface) {
                swapChain?.let { engine.destroySwapChain(it) }; swapChain = engine.createSwapChain(surface)
            }
            override fun onDetachedFromSurface() { swapChain?.let { engine.destroySwapChain(it); engine.flushAndWait() }; swapChain = null }
            override fun onResized(width: Int, height: Int) { vw = width; vh = height; view.viewport = Viewport(0, 0, width, height); updateCamera() }
        }
        helper.attachTo(surfaceView); uiHelper = helper
    }
    fun resume() { if (running) return; running = true; lastFrameNs = 0L; choreographer.postFrameCallback(this) }
    fun pause() { running = false; choreographer.removeFrameCallback(this) }

    fun destroy() {
        pause(); uiHelper?.detach(); uiHelper = null
        swapChain?.let { engine.destroySwapChain(it) }; swapChain = null; engine.flushAndWait()
        clearCells()
        for ((e, _) in loose) { scene.removeEntity(e); engine.destroyEntity(e); EntityManager.get().destroy(e) }
        for (mi in looseMis) engine.destroyMaterialInstance(mi)
        scene.removeEntity(sunEntity); engine.destroyEntity(sunEntity); EntityManager.get().destroy(sunEntity)
        skybox?.let { engine.destroySkybox(it) }; indirect?.let { engine.destroyIndirectLight(it) }
        engine.destroyVertexBuffer(vb); engine.destroyIndexBuffer(ib); engine.destroyMaterial(material)
        engine.destroyRenderer(renderer); engine.destroyView(view); engine.destroyScene(scene)
        engine.destroyCameraComponent(cameraEntity); EntityManager.get().destroy(cameraEntity)
        engine.destroy()
    }
}
