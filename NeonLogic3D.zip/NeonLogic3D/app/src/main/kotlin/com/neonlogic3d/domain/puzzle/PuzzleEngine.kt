package com.neonlogic3d.domain.puzzle

import com.neonlogic3d.domain.model.*
import com.neonlogic3d.domain.solver.Solver

/** Immutable snapshot of authoritative game state. The renderer and UI only read this. */
data class PuzzleState(
    val level: Level, val board: Board, val moves: Int, val hints: Int,
    val connection: ConnectionResult, val completed: Boolean
)

/**
 * Deterministic, Android-free puzzle engine. Completion is only ever set from [Connectivity.evaluate].
 * Not thread-safe: call from a single thread (the UI/main dispatcher).
 */
class PuzzleEngine(private val level: Level, initial: PuzzleState? = null) {
    private val history = ArrayDeque<PuzzleState>()
    var state: PuzzleState = initial ?: fresh()
        private set

    private fun fresh(): PuzzleState = snapshot(level.board, 0, 0)
    private fun snapshot(b: Board, moves: Int, hints: Int): PuzzleState {
        val c = Connectivity.evaluate(b)
        return PuzzleState(level, b, moves, hints, c, c.solved)
    }

    /** Rotates the tile at (r,c) by 90 degrees clockwise. Returns false (no state change) when illegal. */
    fun rotate(r: Int, c: Int): Boolean {
        if (state.completed || !state.board.inBounds(r, c)) return false
        val t = state.board[r, c]
        if (!t.rotatable) return false
        history.addLast(state)
        if (history.size > 500) history.removeFirst()
        state = snapshot(state.board.withTile(r, c, t.rotatedClockwise()), state.moves + 1, state.hints)
        return true
    }

    fun undo(): Boolean {
        if (state.completed) return false
        val prev = history.removeLastOrNull() ?: return false
        state = prev.copy(hints = state.hints); return true
    }

    fun restart() { history.clear(); state = fresh() }

    /**
     * Hint: points at a rotatable tile that must change for the current optimal solution.
     * Never changes the board; only counts the hint. Returns null if nothing to suggest.
     */
    fun hint(): Pos? {
        if (state.completed) return null
        val sol = Solver.solve(state.board) ?: return null
        for (r in 0 until state.board.rows) for (c in 0 until state.board.cols) {
            val cur = state.board[r, c]
            if (cur.rotatable && cur.mask != sol.solution[r, c].mask) {
                state = state.copy(hints = state.hints + 1); return Pos(r, c)
            }
        }
        return null
    }

    companion object {
        /** Stars: 3 = within par and no hints, 2 = within 1.5x par (or hints used), 1 = otherwise. */
        fun stars(moves: Int, par: Int, hints: Int): Int {
            val s = when { moves <= par -> 3; moves <= Math.ceil(par * 1.5).toInt() -> 2; else -> 1 }
            return if (hints > 0) minOf(s, 2) else s
        }
        /** Rebuilds an engine from saved orientations; returns null if the data does not fit the level. */
        fun restore(level: Level, orientations: List<Int>, moves: Int, hints: Int): PuzzleEngine? {
            val b = level.board
            if (orientations.size != b.rows * b.cols || moves < 0 || hints < 0) return null
            var board = b
            for (r in 0 until b.rows) for (c in 0 until b.cols) {
                val o = orientations[r * b.cols + c]; val t = b[r, c]
                if (o !in 0..3 || (!t.rotatable && o != t.orientation)) return null
                board = board.withTile(r, c, t.copy(orientation = o))
            }
            val c = Connectivity.evaluate(board)
            if (c.solved) return null // never resume an already-finished state
            return PuzzleEngine(level, PuzzleState(level, board, moves, hints, c, false))
        }
    }
}
