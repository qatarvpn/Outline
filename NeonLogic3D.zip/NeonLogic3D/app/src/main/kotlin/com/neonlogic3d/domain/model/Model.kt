package com.neonlogic3d.domain.model

/** Directions as bitmask bits. Order N, E, S, W matches clockwise rotation. */
object Dir {
    const val N = 1; const val E = 2; const val S = 4; const val W = 8
    val ALL = intArrayOf(N, E, S, W)
    fun dr(d: Int) = when (d) { N -> -1; S -> 1; else -> 0 }
    fun dc(d: Int) = when (d) { E -> 1; W -> -1; else -> 0 }
    fun opposite(d: Int) = when (d) { N -> S; S -> N; E -> W; else -> E }
    /** Rotates a 4-bit port mask clockwise by [quarterTurns] * 90 degrees. */
    fun rotate(mask: Int, quarterTurns: Int): Int {
        var m = mask and 15
        repeat(((quarterTurns % 4) + 4) % 4) { m = ((m shl 1) or (m shr 3)) and 15 }
        return m
    }
}

enum class TileType(val code: Char, val baseMask: Int, val alwaysFixed: Boolean) {
    STRAIGHT('I', Dir.N or Dir.S, false),
    ELBOW('L', Dir.N or Dir.E, false),
    TEE('T', Dir.N or Dir.E or Dir.W, false),
    CROSS('X', 15, false),
    SOURCE('O', Dir.N, true),
    TARGET('G', Dir.N, true),
    BLOCKED('#', 0, true),
    EMPTY('.', 0, true);

    /** Blocked and empty cells never take part in a connection. */
    val connectable get() = this != BLOCKED && this != EMPTY
    companion object { fun fromCode(c: Char) = entries.firstOrNull { it.code == c } ?: error("Unknown tile type '$c'") }
}

/** [orientation] is the number of clockwise quarter turns applied to the type's base mask (0..3). */
data class Tile(val type: TileType, val orientation: Int, val fixed: Boolean) {
    init { require(orientation in 0..3) { "orientation out of range" } }
    val mask: Int get() = Dir.rotate(type.baseMask, orientation)
    val rotatable: Boolean get() = !fixed && !type.alwaysFixed
    fun rotatedClockwise() = copy(orientation = (orientation + 1) % 4)
}

data class Pos(val r: Int, val c: Int)

class Board(val rows: Int, val cols: Int, private val cells: List<Tile>) {
    init { require(rows > 0 && cols > 0 && cells.size == rows * cols) { "invalid board dimensions" } }
    operator fun get(r: Int, c: Int) = cells[r * cols + c]
    operator fun get(p: Pos) = get(p.r, p.c)
    fun inBounds(r: Int, c: Int) = r in 0 until rows && c in 0 until cols
    fun withTile(r: Int, c: Int, t: Tile): Board = Board(rows, cols, cells.toMutableList().also { it[r * cols + c] = t })
    fun find(type: TileType): List<Pos> = buildList { for (r in 0 until rows) for (c in 0 until cols) if (get(r, c).type == type) add(Pos(r, c)) }
    fun orientations(): List<Int> = cells.map { it.orientation }
    override fun equals(other: Any?) = other is Board && rows == other.rows && cols == other.cols && cells == other.cells
    override fun hashCode() = cells.hashCode() * 31 + rows
}

data class Level(
    val id: Int, val chapter: Int, val board: Board, val solution: Board,
    val par: Int, val difficulty: Int, val rule: String = "path"
) { val source: Pos get() = board.find(TileType.SOURCE).single(); val target: Pos get() = board.find(TileType.TARGET).single() }
