package com.neonlogic3d.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.neonlogic3d.data.persistence.Settings
import com.neonlogic3d.domain.model.TileType
import com.neonlogic3d.graphics.BoardRenderer

@Composable fun GameScreen(vm: AppViewModel, renderer: BoardRenderer, g: GameUi, settings: Settings) {
    val st = g.state; val level = st.level
    val gNow by rememberUpdatedState(g); val sNow by rememberUpdatedState(settings)
    LaunchedEffect(st) { renderer.submit(st) }
    LaunchedEffect(g.paused) { renderer.paused = g.paused }
    LaunchedEffect(Unit) { vm.hints.collect { renderer.flashHint(it) } }
    DisposableEffect(Unit) { onDispose { renderer.paused = false } }
    var showSettings by remember { mutableStateOf(false) }
    BackHandler { if (g.showComplete) vm.exitToMenu() else vm.setPaused(!g.paused) }

    Box(Modifier.fillMaxSize()) {
        // Gesture layer for the 3D board: tap = rotate (ray-cast picked), horizontal drag = orbit camera.
        Box(Modifier.fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures { o ->
                    val cur = gNow
                    if (cur.paused || cur.showComplete || cur.state.completed || renderer.isBusy) return@detectTapGestures
                    renderer.pickCell(o.x, o.y)?.let { if (vm.onTap(it)) renderer.pulse(it) }
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures { _, dx -> renderer.setCameraYaw(renderer.yaw + dx * 0.004f * (0.3f + sNow.camSensitivity * 1.4f)) }
            })

        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            // top bar (consumes touches so button gaps never rotate tiles)
            Row(Modifier.fillMaxWidth().padding(12.dp).pointerInput(Unit) { detectTapGestures { } }, verticalAlignment = Alignment.CenterVertically) {
                RoundIcon(Icons.Filled.Pause, "Pause", { vm.setPaused(true) })
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (g.daily) "Daily Puzzle" else "Level ${level.id}", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    Text("Moves: ${st.moves} / ${level.par}", color = NeonColors.Muted, fontSize = 14.sp, modifier = Modifier.semantics { contentDescription = "Moves ${st.moves}, par ${level.par}" })
                }
                RoundIcon(Icons.Filled.Undo, "Undo", { vm.undo() })
            }
            if (g.coach && !g.state.completed) {
                val msg = if (st.moves == 0) "Tap a tile to rotate it 90°" else "Connect the cyan source to the amber target"
                Text(msg, Modifier.align(Alignment.CenterHorizontally).clip(RoundedCornerShape(12.dp)).background(NeonColors.Panel).padding(horizontal = 14.dp, vertical = 8.dp), color = NeonColors.Text, fontSize = 15.sp)
            }
            Spacer(Modifier.weight(1f))
            // energy indicator
            val total = (0 until st.board.rows * st.board.cols).count { st.board[it / st.board.cols, it % st.board.cols].type.connectable }
            val frac = if (st.completed) 1f else st.connection.reached.size / total.toFloat().coerceAtLeast(1f)
            LinearProgressIndicator(progress = { frac }, Modifier.align(Alignment.CenterHorizontally).width(220.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).semantics { contentDescription = "Energy flow ${(frac * 100).toInt()} percent" }, color = NeonColors.Cyan, trackColor = NeonColors.Locked)
            Row(Modifier.fillMaxWidth().padding(16.dp).pointerInput(Unit) { detectTapGestures { } }, horizontalArrangement = Arrangement.SpaceEvenly) {
                BottomAction(Icons.Filled.ArrowBack, "Back") { vm.backToLevels() }
                BottomAction(Icons.Filled.Lightbulb, "Hint", badge = st.hints.takeIf { it > 0 }) { vm.requestHint() }
                BottomAction(Icons.Filled.Refresh, "Restart") { vm.restart() }
            }
        }

        if (g.paused && !g.showComplete) Scrim {
            GlassPanel(Modifier.padding(32.dp).fillMaxWidth()) {
                Text("Paused", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                Spacer(Modifier.height(14.dp))
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    NeonButton("Resume", { vm.setPaused(false) }, Modifier.fillMaxWidth(), NeonColors.Green, Icons.Filled.PlayArrow)
                    NeonButton("Restart Level", { vm.restart() }, Modifier.fillMaxWidth(), NeonColors.Blue, Icons.Filled.Refresh)
                    NeonButton("Settings", { showSettings = true }, Modifier.fillMaxWidth(), NeonColors.Blue, Icons.Filled.Settings)
                    NeonButton("Exit to Menu", { vm.exitToMenu() }, Modifier.fillMaxWidth(), NeonColors.Blue, Icons.Filled.Home)
                }
            }
        }
        if (g.showComplete) Scrim {
            Column(Modifier.padding(28.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Stars(g.stars, 56)
                Text("Level Completed!", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 12.dp))
                GlassPanel(Modifier.fillMaxWidth()) {
                    Row { Text("Moves Used", color = NeonColors.Text); Spacer(Modifier.weight(1f)); Text("${st.moves}", color = NeonColors.Text, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.height(6.dp))
                    Row { Text("Par Target", color = NeonColors.Text); Spacer(Modifier.weight(1f)); Text("${level.par}", color = NeonColors.Text, fontWeight = FontWeight.Bold) }
                    if (st.hints > 0) { Spacer(Modifier.height(6.dp)); Row { Text("Hints Used", color = NeonColors.Text); Spacer(Modifier.weight(1f)); Text("${st.hints}", color = NeonColors.Text) } }
                }
                Spacer(Modifier.height(14.dp))
                if (!g.daily && level.id < LEVEL_COUNT) NeonButton("Next Level", { vm.nextLevel() }, Modifier.fillMaxWidth(), NeonColors.Green)
                Spacer(Modifier.height(10.dp)); NeonButton("Replay", { vm.restart() }, Modifier.fillMaxWidth(), NeonColors.Blue)
                Spacer(Modifier.height(10.dp)); NeonButton("Menu", { vm.exitToMenu() }, Modifier.fillMaxWidth(), NeonColors.Locked)
            }
        }
    }
    if (showSettings) AlertDialog(onDismissRequest = { showSettings = false }, title = { Text("Settings") }, confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Done") } },
        text = { Column {
            LabeledSlider("Music", settings.music) { v -> vm.updateSettings { it.copy(music = v) } }
            LabeledSlider("Sound Effects", settings.sfx) { v -> vm.updateSettings { it.copy(sfx = v) } }
            LabeledSlider("Camera Sensitivity", settings.camSensitivity) { v -> vm.updateSettings { it.copy(camSensitivity = v) } }
            SwitchRow("Haptic Feedback", settings.haptics) { v -> vm.updateSettings { it.copy(haptics = v) } }
        } })
}

@Composable private fun Scrim(content: @Composable BoxScope.() -> Unit) =
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xCC020611), Color(0xEE020611)))).pointerInput(Unit) { detectTapGestures { } }, contentAlignment = Alignment.Center, content = content)

@Composable private fun BottomAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, badge: Int? = null, onClick: () -> Unit) {
    Box {
        Column(Modifier.width(88.dp).heightIn(min = 56.dp).clip(RoundedCornerShape(14.dp)).background(NeonColors.Panel).border(1.dp, NeonColors.Border, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick).padding(vertical = 8.dp).semantics { contentDescription = if (badge != null) "$label, $badge used" else label }, horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(26.dp)); Text(label, color = NeonColors.Text, fontSize = 12.sp)
        }
        if (badge != null) Box(Modifier.align(Alignment.TopEnd).size(22.dp).clip(RoundedCornerShape(11.dp)).background(NeonColors.Blue), contentAlignment = Alignment.Center) { Text("$badge", color = Color.White, fontSize = 12.sp) }
    }
}
