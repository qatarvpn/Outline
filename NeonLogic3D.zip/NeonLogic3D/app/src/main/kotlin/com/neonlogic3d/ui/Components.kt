package com.neonlogic3d.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.neonlogic3d.domain.model.Dir

object NeonColors {
    val BgTop = Color(0xFF040A1C); val BgBottom = Color(0xFF0B1F45); val Panel = Color(0xCC0A1B3D); val Border = Color(0xFF2B6FD6)
    val Cyan = Color(0xFF19D3FF); val Green = Color(0xFF1FB964); val Blue = Color(0xFF1F6BFF); val Amber = Color(0xFFFFC53D)
    val Text = Color(0xFFEAF4FF); val Muted = Color(0xFF8FA6C8); val Danger = Color(0xFFD62F4B); val Locked = Color(0xFF14264A)
}

@Composable fun NeonTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = NeonColors.Cyan, background = NeonColors.BgTop, surface = NeonColors.BgBottom, onSurface = NeonColors.Text),
    content = content
)

@Composable fun ScreenBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) =
    Box(modifier.fillMaxSize().background(Brush.verticalGradient(listOf(NeonColors.BgTop, NeonColors.BgBottom))).statusBarsPadding().navigationBarsPadding(), content = content)

@Composable fun NeonButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, color: Color = NeonColors.Blue, icon: ImageVector? = null, enabled: Boolean = true) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier.heightIn(min = 56.dp).clip(shape)
            .background(Brush.verticalGradient(listOf(color, color.copy(alpha = 0.7f)))).border(1.dp, Color.White.copy(alpha = 0.25f), shape)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(24.dp)); Spacer(Modifier.width(10.dp)) }
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
    }
}

@Composable fun GlassPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Column(modifier.clip(shape).background(NeonColors.Panel).border(1.dp, NeonColors.Border.copy(alpha = 0.6f), shape).padding(16.dp), content = content)
}

@Composable fun RoundIcon(icon: ImageVector, desc: String, onClick: () -> Unit, modifier: Modifier = Modifier, tint: Color = Color.White) {
    Box(modifier.size(48.dp).clip(RoundedCornerShape(24.dp)).background(NeonColors.Panel).border(1.dp, NeonColors.Border, RoundedCornerShape(24.dp))
        .clickable(role = Role.Button, onClick = onClick).semantics { contentDescription = desc }, contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(26.dp))
    }
}

@Composable fun TopBar(title: String, onBack: (() -> Unit)?, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) RoundIcon(Icons.Filled.ArrowBack, "Back", onBack) else Spacer(Modifier.size(48.dp))
        Text(title, Modifier.weight(1f), color = NeonColors.Text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) { trailing() }
    }
}

/** Stars use both shape and colour (filled vs outlined) so state is not conveyed by colour alone. */
@Composable fun Stars(count: Int, size: Int = 18, total: Int = 3) {
    Row(Modifier.semantics { contentDescription = "$count of $total stars" }) {
        for (i in 1..total) Icon(if (i <= count) Icons.Filled.Star else Icons.Filled.StarBorder, null,
            tint = if (i <= count) NeonColors.Amber else NeonColors.Muted.copy(alpha = 0.6f), modifier = Modifier.size(size.dp))
    }
}

/** Draws the connection ports of a tile (used by the tutorial). */
@Composable fun TileGlyph(mask: Int, color: Color = NeonColors.Cyan, size: Int = 96) {
    Canvas(Modifier.size(size.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF1B2540)).border(1.dp, NeonColors.Border, RoundedCornerShape(14.dp))) {
        val c = Offset(this.size.width / 2, this.size.height / 2); val w = this.size.width * 0.14f
        for (d in Dir.ALL) if (mask and d != 0) {
            val end = when (d) { Dir.N -> Offset(c.x, 0f); Dir.S -> Offset(c.x, this.size.height); Dir.E -> Offset(this.size.width, c.y); else -> Offset(0f, c.y) }
            drawLine(color, c, end, strokeWidth = w, cap = StrokeCap.Butt)
        }
        drawCircle(color, w * 1.1f, c)
    }
}
