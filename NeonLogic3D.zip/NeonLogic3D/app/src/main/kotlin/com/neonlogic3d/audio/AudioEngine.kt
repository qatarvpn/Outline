package com.neonlogic3d.audio

import android.content.Context
import android.media.*
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import kotlin.math.*

enum class Sfx { ROTATE, CONNECT, INVALID, ENERGY, COMPLETE, MENU }

/** Original, procedurally synthesised sounds (no asset files, no downloads). Respects audio focus. */
class AudioEngine(private val context: Context) {
    private val sr = 22050
    private val tracks = HashMap<Sfx, AudioTrack>()
    private var music: AudioTrack? = null
    private var focusRequest: AudioFocusRequest? = null
    private val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator?
    var sfxVolume = 0.8f; var sfxOn = true; var musicVolume = 0.7f; var musicOn = true; var haptics = true
    private var foreground = false

    private fun chirp(notes: List<Triple<Float, Float, Int>>, vol: Float): ShortArray {
        val out = ArrayList<Short>()
        for ((f0, f1, ms) in notes) {
            val n = sr * ms / 1000; var phase = 0.0
            for (i in 0 until n) {
                val t = i.toFloat() / n; val f = f0 + (f1 - f0) * t
                phase += 2 * PI * f / sr
                val env = min(1f, i / 80f) * (1f - t).pow(1.6f)
                out.add((sin(phase) * env * vol * 32767).toInt().toShort())
            }
        }
        return out.toShortArray()
    }
    private fun data(s: Sfx): ShortArray = when (s) {
        Sfx.ROTATE -> chirp(listOf(Triple(820f, 560f, 75)), 0.45f)
        Sfx.CONNECT -> chirp(listOf(Triple(520f, 880f, 130)), 0.4f)
        Sfx.INVALID -> chirp(listOf(Triple(210f, 150f, 130)), 0.45f)
        Sfx.ENERGY -> chirp(listOf(Triple(300f, 1200f, 380)), 0.35f)
        Sfx.COMPLETE -> chirp(listOf(Triple(523f, 523f, 130), Triple(659f, 659f, 130), Triple(784f, 784f, 130), Triple(1047f, 1047f, 360)), 0.45f)
        Sfx.MENU -> chirp(listOf(Triple(700f, 760f, 45)), 0.3f)
    }
    private fun staticTrack(pcm: ShortArray): AudioTrack {
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(sr).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
        t.write(pcm, 0, pcm.size); return t
    }

    fun play(s: Sfx) {
        if (!sfxOn || sfxVolume <= 0f) return
        runCatching {
            val t = tracks.getOrPut(s) { staticTrack(data(s)) }
            t.stop(); t.reloadStaticData(); t.setVolume(sfxVolume); t.play()
        }
    }
    fun tick() {
        if (!haptics) return
        runCatching { if (Build.VERSION.SDK_INT >= 26) vibrator?.vibrate(VibrationEffect.createOneShot(14, 60)) else @Suppress("DEPRECATION") vibrator?.vibrate(14) }
    }

    private fun musicData(): ShortArray {
        val secs = 8; val n = sr * secs; val out = ShortArray(n); val chord = floatArrayOf(110f, 164.8f, 220f, 277.2f)
        for (i in 0 until n) {
            val t = i.toFloat() / sr; var v = 0f
            for ((k, f) in chord.withIndex()) v += sin(2 * PI * f * t + k).toFloat() * (0.5f + 0.5f * sin(2 * PI * (t / secs) * (k + 1)).toFloat()) * 0.12f
            out[i] = (v * 32767).toInt().toShort()
        }
        return out
    }
    /** Call from onResume/onPause. */
    fun setForeground(fg: Boolean) { foreground = fg; refreshMusic() }
    fun refreshMusic() {
        val want = foreground && musicOn && musicVolume > 0f
        if (want) {
            if (!requestFocus()) return
            runCatching {
                val m = music ?: staticTrack(musicData()).also { it.setLoopPoints(0, it.bufferSizeInFrames, -1); music = it }
                m.setVolume(musicVolume * 0.6f); if (m.playState != AudioTrack.PLAYSTATE_PLAYING) m.play()
            }
        } else { runCatching { music?.pause() }; abandonFocus() }
    }
    private fun requestFocus(): Boolean {
        if (Build.VERSION.SDK_INT < 26) return true
        if (focusRequest != null) return true
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).build())
            .setOnAudioFocusChangeListener { change -> if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) runCatching { music?.pause() } else if (change == AudioManager.AUDIOFOCUS_GAIN) refreshMusic() }.build()
        val ok = am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        if (ok) focusRequest = req; return ok
    }
    private fun abandonFocus() { if (Build.VERSION.SDK_INT >= 26) focusRequest?.let { am.abandonAudioFocusRequest(it) }; focusRequest = null }
    fun release() { tracks.values.forEach { runCatching { it.release() } }; tracks.clear(); runCatching { music?.release() }; music = null; abandonFocus() }
}
