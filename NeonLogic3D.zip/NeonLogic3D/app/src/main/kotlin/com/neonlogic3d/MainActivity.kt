package com.neonlogic3d

import android.os.Bundle
import android.view.SurfaceView
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import com.neonlogic3d.data.persistence.GraphicsQuality
import com.neonlogic3d.domain.puzzle.Connectivity
import com.neonlogic3d.domain.puzzle.PuzzleState
import com.neonlogic3d.graphics.BoardRenderer
import com.neonlogic3d.ui.*

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()
    private lateinit var renderer: BoardRenderer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        renderer = BoardRenderer(GraphicsQuality.MEDIUM)
        setContent { NeonTheme { NeonApp(vm, renderer) } }
    }
    override fun onResume() { super.onResume(); renderer.resume(); vm.audio.setForeground(true) }
    override fun onPause() { renderer.pause(); vm.audio.setForeground(false); vm.persistNow(); super.onPause() }
    override fun onDestroy() { renderer.destroy(); super.onDestroy() }
}

@Composable fun NeonApp(vm: AppViewModel, renderer: BoardRenderer) {
    val screen by vm.screen.collectAsState(); val repo by vm.repo.collectAsState()
    val progress by vm.progress.collectAsState(); val settings by vm.settings.collectAsState(); val game by vm.game.collectAsState()
    val ready = repo != null && progress != null && settings != null
    val needs3d = screen is Screen.Menu || screen is Screen.Game

    LaunchedEffect(Unit) { renderer.onCelebrationFinished = { vm.onCelebrationFinished() } }
    LaunchedEffect(settings?.quality) { settings?.let { renderer.applyQuality(it.quality) } }
    LaunchedEffect(needs3d) { renderer.renderEnabled = needs3d }
    LaunchedEffect(screen) { renderer.demo = screen is Screen.Menu; if (screen !is Screen.Game) renderer.paused = false }
    // Menu background: a real solved level rendered in 3D with looping energy flow.
    LaunchedEffect(screen, repo) {
        val r = repo ?: return@LaunchedEffect
        if (screen is Screen.Menu) r.byId(12)?.let { lv -> renderer.submit(PuzzleState(lv, lv.solution, 0, 0, Connectivity.evaluate(lv.solution), true)) }
    }
    BackHandler(enabled = screen !is Screen.Splash && screen !is Screen.Menu && screen !is Screen.Game) { vm.go(Screen.Menu) }

    Box(Modifier.fillMaxSize().background(NeonColors.BgTop)) {
        AndroidView(factory = { ctx -> SurfaceView(ctx).also { renderer.attach(it) } }, modifier = Modifier.fillMaxSize())
        val p = progress; val s = settings
        when (val sc = screen) {
            Screen.Splash -> SplashScreen(ready, vm.loadError) { vm.go(Screen.Menu) }
            Screen.Menu -> if (p != null && s != null) MenuScreen(vm, p, s)
            Screen.Chapters -> p?.let { ChaptersScreen(vm, it) }
            is Screen.Levels -> p?.let { LevelsScreen(vm, it, sc.chapter) }
            Screen.Daily -> p?.let { DailyScreen(vm, it) }
            Screen.Settings -> s?.let { SettingsScreen(vm, it) }
            Screen.Tutorial -> TutorialScreen(vm)
            Screen.Game -> { val g = game; if (g != null && s != null) GameScreen(vm, renderer, g, s) }
        }
    }
}
