package com.neonlogic3d.domain.puzzle

import com.neonlogic3d.domain.model.*

/** Result of a deterministic graph traversal from the source. [path] is the BFS route to the target (empty if unsolved). */
data class ConnectionResult(val solved: Boolean, val reached: Set<Pos>, val path: List<Pos>)

object Connectivity {
    /** Breadth-first search over *reciprocal* ports only; visual adjacency never counts. */
    fun evaluate(board: Board): ConnectionResult {
        val sources = board.find(TileType.SOURCE); val targets = board.find(TileType.TARGET)
        if (sources.size != 1 || targets.size != 1) return ConnectionResult(false, emptySet(), emptyList())
        val start = sources[0]; val goal = targets[0]
        val parent = HashMap<Pos, Pos?>(); parent[start] = null
        val queue = ArrayDeque<Pos>(); queue.add(start)
        while (queue.isNotEmpty()) {
            val p = queue.removeFirst()
            val m = board[p].mask
            for (d in Dir.ALL) {
                if (m and d == 0) continue
                val nr = p.r + Dir.dr(d); val nc = p.c + Dir.dc(d)
                if (!board.inBounds(nr, nc)) continue
                val n = Pos(nr, nc)
                if (n in parent) continue
                val t = board[n]
                if (!t.type.connectable || t.mask and Dir.opposite(d) == 0) continue
                parent[n] = p; queue.add(n)
            }
        }
        if (goal !in parent) return ConnectionResult(false, parent.keys, emptyList())
        val path = ArrayList<Pos>(); var cur: Pos? = goal
        while (cur != null) { path.add(cur); cur = parent[cur] }
        path.reverse()
        return ConnectionResult(true, parent.keys, path)
    }
}
