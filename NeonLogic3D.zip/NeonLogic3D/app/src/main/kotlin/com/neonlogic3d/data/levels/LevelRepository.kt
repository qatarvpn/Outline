package com.neonlogic3d.data.levels

import com.neonlogic3d.domain.model.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable data class LevelDto(
    val id: Int, val chapter: Int, val rows: Int, val cols: Int, val source: List<Int>, val target: List<Int>,
    val tiles: List<String>, val solution: List<String>, val par: Int, val difficulty: Int, val rule: String = "path"
)
@Serializable data class LevelFile(val version: Int, val levels: List<LevelDto>)

object LevelParser {
    const val SUPPORTED_VERSION = 1
    private val json = Json { ignoreUnknownKeys = true }

    fun parseBoard(rows: List<String>, nRows: Int, nCols: Int): Board {
        require(rows.size == nRows) { "expected $nRows rows" }
        val cells = ArrayList<Tile>()
        for (line in rows) {
            val toks = line.trim().split(Regex("\\s+"))
            require(toks.size == nCols) { "expected $nCols tiles per row" }
            for (tok in toks) {
                require(tok.length >= 2) { "bad token '$tok'" }
                val type = TileType.fromCode(tok[0]); val o = tok[1] - '0'
                require(o in 0..3) { "bad orientation in '$tok'" }
                cells.add(Tile(type, o, tok.endsWith("!") || type.alwaysFixed))
            }
        }
        return Board(nRows, nCols, cells)
    }

    fun parse(text: String): List<Level> {
        val f = json.decodeFromString(LevelFile.serializer(), text)
        require(f.version == SUPPORTED_VERSION) { "unsupported level file version ${f.version}" }
        return f.levels.map { d ->
            val b = parseBoard(d.tiles, d.rows, d.cols); val s = parseBoard(d.solution, d.rows, d.cols)
            Level(d.id, d.chapter, b, s, d.par, d.difficulty, d.rule)
        }
    }
}

class LevelRepository(private val levels: List<Level>) {
    val all: List<Level> get() = levels
    val count get() = levels.size
    fun byId(id: Int) = levels.firstOrNull { it.id == id }
    fun chapter(ch: Int) = levels.filter { it.chapter == ch }
    companion object {
        fun fromAsset(context: android.content.Context) =
            LevelRepository(LevelParser.parse(context.assets.open("levels.json").bufferedReader().use { it.readText() }))
    }
}
