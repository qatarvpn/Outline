package com.neonlogic3d.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.neonlogic3d.audio.AudioEngine
import com.neonlogic3d.audio.Sfx
import com.neonlogic3d.data.levels.LevelRepository
import com.neonlogic3d.data.persistence.*
import com.neonlogic3d.domain.model.Pos
import com.neonlogic3d.domain.puzzle.PuzzleEngine
import com.neonlogic3d.domain.puzzle.PuzzleState
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

sealed interface Screen {
    data object Splash : Screen; data object Menu : Screen; data object Chapters : Screen
    data class Levels(val chapter: Int) : Screen; data object Daily : Screen; data object Settings : Screen
    data object Tutorial : Screen; data object Game : Screen
}
data class GameUi(
    val state: PuzzleState, val paused: Boolean = false, val showComplete: Boolean = false, val stars: Int = 0,
    val daily: Boolean = false, val coach: Boolean = false
)

const val LEVEL_COUNT = 100
const val EPOCH_DAY_MS = 86_400_000L
fun todayEpochDay(): Long = (System.currentTimeMillis() + java.util.TimeZone.getDefault().getOffset(System.currentTimeMillis())) / EPOCH_DAY_MS
/** Daily puzzle: deterministic pick from the harder 60 levels. */
fun dailyLevelId(epochDay: Long): Int = 41 + (((epochDay * 2654435761L) ushr 3) % 60).toInt()

class AppViewModel(app: Application) : AndroidViewModel(app) {
    val audio = AudioEngine(app)
    private val store = ProgressStore(app, LEVEL_COUNT)
    private val _repo = MutableStateFlow<LevelRepository?>(null); val repo = _repo.asStateFlow()
    val progress: StateFlow<Progress?> = store.progress.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val settings: StateFlow<Settings?> = store.settings.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    private val _screen = MutableStateFlow<Screen>(Screen.Splash); val screen = _screen.asStateFlow()
    private val _game = MutableStateFlow<GameUi?>(null); val game = _game.asStateFlow()
    private val _hint = MutableSharedFlow<Pos>(extraBufferCapacity = 4); val hints = _hint.asSharedFlow()
    private var engine: PuzzleEngine? = null
    var loadError: String? = null; private set

    init {
        viewModelScope.launch(Dispatchers.IO) {
            try { _repo.value = LevelRepository.fromAsset(app) } catch (e: Exception) { loadError = e.message }
        }
        viewModelScope.launch {
            settings.filterNotNull().collect { s ->
                audio.sfxVolume = s.sfx; audio.sfxOn = s.sfxOn; audio.musicVolume = s.music; audio.musicOn = s.musicOn; audio.haptics = s.haptics; audio.refreshMusic()
            }
        }
    }

    fun go(s: Screen) { audio.play(Sfx.MENU); _screen.value = s }

    fun startLevel(id: Int, daily: Boolean = false, coach: Boolean = false) {
        val lv = repo.value?.byId(id) ?: return
        engine = PuzzleEngine(lv)
        _game.value = GameUi(engine!!.state, daily = daily, coach = coach)
        if (!daily) viewModelScope.launch { store.setCurrent(id); store.clearPuzzle() }
        _screen.value = Screen.Game
    }

    fun continueGame() {
        val p = progress.value ?: return; val r = repo.value ?: return
        val saved = p.saved
        val lv = saved?.let { r.byId(it.levelId) }
        val restored = if (saved != null && lv != null) PuzzleEngine.restore(lv, saved.orientations, saved.moves, saved.hints) else null
        if (restored != null) { engine = restored; _game.value = GameUi(restored.state); _screen.value = Screen.Game }
        else startLevel(p.currentLevel.coerceAtMost(p.highestUnlocked), coach = !p.tutorialDone)
    }

    fun startDaily() { startLevel(dailyLevelId(todayEpochDay()), daily = true) }

    /** Returns true if a rotation was performed. */
    fun onTap(p: Pos): Boolean {
        val g = game.value ?: return false; val e = engine ?: return false
        if (g.paused || g.showComplete || g.state.completed) return false
        if (!e.rotate(p.r, p.c)) { audio.play(Sfx.INVALID); return false }
        audio.play(Sfx.ROTATE); audio.tick()
        val st = e.state
        if (st.completed) {
            val stars = PuzzleEngine.stars(st.moves, st.level.par, st.hints)
            audio.play(Sfx.ENERGY)
            _game.value = g.copy(state = st, stars = stars)
            viewModelScope.launch {
                if (g.daily) store.markDaily(todayEpochDay()) else { store.recordCompletion(st.level.id, st.moves, stars) }
                if (g.coach) store.markTutorial()
            }
        } else {
            _game.value = g.copy(state = st)
            if (!g.daily) viewModelScope.launch { store.savePuzzle(SavedPuzzle(st.level.id, st.board.orientations(), st.moves, st.hints)) }
        }
        return true
    }
    fun onCelebrationFinished() { val g = game.value ?: return; if (g.state.completed && !g.showComplete) { audio.play(Sfx.COMPLETE); _game.value = g.copy(showComplete = true) } }
    fun setPaused(p: Boolean) { _game.value = _game.value?.copy(paused = p) }
    fun restart() {
        val e = engine ?: return; e.restart()
        _game.value = _game.value?.copy(state = e.state, paused = false, showComplete = false, stars = 0)
        if (_game.value?.daily == false) viewModelScope.launch { store.clearPuzzle() }
    }
    fun requestHint() {
        val g = game.value ?: return; val e = engine ?: return
        val p = e.hint()
        if (p != null) { _game.value = g.copy(state = e.state); _hint.tryEmit(p); audio.play(Sfx.CONNECT) } else audio.play(Sfx.INVALID)
    }
    fun undo() {
        val g = game.value ?: return; val e = engine ?: return
        if (g.paused || g.showComplete || g.state.completed) return
        if (e.undo()) { _game.value = g.copy(state = e.state); audio.play(Sfx.ROTATE) } else audio.play(Sfx.INVALID)
    }
    fun nextLevel() { val id = game.value?.state?.level?.id ?: return; if (id < LEVEL_COUNT) startLevel(id + 1) else exitToMenu() }
    fun exitToMenu() { persistNow(); _game.value = null; engine = null; _screen.value = Screen.Menu }
    fun backToLevels() { val ch = game.value?.state?.level?.chapter ?: 1; persistNow(); _game.value = null; engine = null; _screen.value = Screen.Levels(ch) }
    fun persistNow() {
        val st = engine?.state ?: return; val g = game.value ?: return
        if (!st.completed && !g.daily) viewModelScope.launch { store.savePuzzle(SavedPuzzle(st.level.id, st.board.orientations(), st.moves, st.hints)) }
    }
    fun updateSettings(f: (Settings) -> Settings) { viewModelScope.launch { store.updateSettings(f) } }
    fun resetProgress() { viewModelScope.launch { store.resetProgress() } }
    fun markTutorialSeen() { viewModelScope.launch { store.markTutorial() } }
    override fun onCleared() { audio.release() }
}
