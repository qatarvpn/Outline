package com.neonlogic3d.data.persistence

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.*

enum class GraphicsQuality { LOW, MEDIUM, HIGH }

data class Settings(
    val music: Float = 0.7f, val sfx: Float = 0.8f, val musicOn: Boolean = true, val sfxOn: Boolean = true,
    val haptics: Boolean = true, val quality: GraphicsQuality = GraphicsQuality.MEDIUM, val camSensitivity: Float = 0.5f
)
data class SavedPuzzle(val levelId: Int, val orientations: List<Int>, val moves: Int, val hints: Int)
data class Progress(
    val highestUnlocked: Int = 1, val stars: Map<Int, Int> = emptyMap(), val bestMoves: Map<Int, Int> = emptyMap(),
    val currentLevel: Int = 1, val saved: SavedPuzzle? = null, val dailyDoneDay: Long = -1, val tutorialDone: Boolean = false
) {
    val completedCount get() = stars.size
    val totalStars get() = stars.values.sum()
}

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(
    name = "neon_logic_v1", corruptionHandler = ReplaceFileCorruptionHandler { emptyPreferences() }
)

/** All persistence goes through DataStore (off the main thread). Every parser is defensive against corrupt/outdated data. */
class ProgressStore(private val context: Context, private val levelCount: Int) {
    private object K {
        val version = intPreferencesKey("save_version")
        val unlocked = intPreferencesKey("unlocked"); val stars = stringPreferencesKey("stars"); val best = stringPreferencesKey("best")
        val current = intPreferencesKey("current"); val saved = stringPreferencesKey("saved_puzzle")
        val daily = longPreferencesKey("daily_day"); val tutorial = booleanPreferencesKey("tutorial")
        val music = floatPreferencesKey("music"); val sfx = floatPreferencesKey("sfx")
        val musicOn = booleanPreferencesKey("music_on"); val sfxOn = booleanPreferencesKey("sfx_on")
        val haptics = booleanPreferencesKey("haptics"); val quality = stringPreferencesKey("quality"); val cam = floatPreferencesKey("cam")
    }
    private val ds get() = context.dataStore
    companion object {
        const val SAVE_VERSION = 1
        fun encodeMap(m: Map<Int, Int>) = m.entries.joinToString(",") { "${it.key}:${it.value}" }
        fun decodeMap(s: String?, maxId: Int): Map<Int, Int> {
            if (s.isNullOrBlank()) return emptyMap()
            val out = HashMap<Int, Int>()
            for (p in s.split(",")) { val kv = p.split(":"); val k = kv.getOrNull(0)?.toIntOrNull(); val v = kv.getOrNull(1)?.toIntOrNull()
                if (k != null && v != null && k in 1..maxId && v >= 0) out[k] = v }
            return out
        }
        fun encodeSaved(s: SavedPuzzle) = "v1|${s.levelId}|${s.moves}|${s.hints}|${s.orientations.joinToString("")}"
        fun decodeSaved(s: String?): SavedPuzzle? {
            val p = s?.split("|") ?: return null
            if (p.size != 5 || p[0] != "v1") return null
            val id = p[1].toIntOrNull() ?: return null; val m = p[2].toIntOrNull() ?: return null; val h = p[3].toIntOrNull() ?: return null
            val o = p[4].map { it - '0' }; if (o.any { it !in 0..3 }) return null
            return SavedPuzzle(id, o, m, h)
        }
    }

    val progress: Flow<Progress> = ds.data.map { p ->
        // Outdated/unknown save versions fall back to a fresh profile instead of crashing.
        if ((p[K.version] ?: SAVE_VERSION) > SAVE_VERSION) return@map Progress()
        val stars = decodeMap(p[K.stars], levelCount)
        Progress(
            highestUnlocked = (p[K.unlocked] ?: 1).coerceIn(1, levelCount), stars = stars, bestMoves = decodeMap(p[K.best], levelCount),
            currentLevel = (p[K.current] ?: 1).coerceIn(1, levelCount), saved = decodeSaved(p[K.saved]),
            dailyDoneDay = p[K.daily] ?: -1, tutorialDone = p[K.tutorial] ?: false
        )
    }
    val settings: Flow<Settings> = ds.data.map { p ->
        Settings(p[K.music] ?: 0.7f, p[K.sfx] ?: 0.8f, p[K.musicOn] ?: true, p[K.sfxOn] ?: true, p[K.haptics] ?: true,
            runCatching { GraphicsQuality.valueOf(p[K.quality] ?: "MEDIUM") }.getOrDefault(GraphicsQuality.MEDIUM), p[K.cam] ?: 0.5f)
    }

    suspend fun recordCompletion(levelId: Int, moves: Int, stars: Int) = ds.edit { p ->
        p[K.version] = SAVE_VERSION
        val s = decodeMap(p[K.stars], levelCount).toMutableMap(); val b = decodeMap(p[K.best], levelCount).toMutableMap()
        s[levelId] = maxOf(s[levelId] ?: 0, stars); b[levelId] = minOf(b[levelId] ?: Int.MAX_VALUE, moves)
        p[K.stars] = encodeMap(s); p[K.best] = encodeMap(b)
        p[K.unlocked] = maxOf(p[K.unlocked] ?: 1, minOf(levelId + 1, levelCount))
        p[K.current] = minOf(levelId + 1, levelCount); p.remove(K.saved)
    }
    suspend fun setCurrent(levelId: Int) = ds.edit { it[K.version] = SAVE_VERSION; it[K.current] = levelId }
    suspend fun savePuzzle(s: SavedPuzzle) = ds.edit { it[K.version] = SAVE_VERSION; it[K.saved] = encodeSaved(s); it[K.current] = s.levelId }
    suspend fun clearPuzzle() = ds.edit { it.remove(K.saved) }
    suspend fun markDaily(day: Long) = ds.edit { it[K.daily] = day }
    suspend fun markTutorial() = ds.edit { it[K.tutorial] = true }
    suspend fun updateSettings(f: (Settings) -> Settings) = ds.edit { p ->
        val n = f(Settings(p[K.music] ?: 0.7f, p[K.sfx] ?: 0.8f, p[K.musicOn] ?: true, p[K.sfxOn] ?: true, p[K.haptics] ?: true,
            runCatching { GraphicsQuality.valueOf(p[K.quality] ?: "MEDIUM") }.getOrDefault(GraphicsQuality.MEDIUM), p[K.cam] ?: 0.5f))
        p[K.music] = n.music.coerceIn(0f, 1f); p[K.sfx] = n.sfx.coerceIn(0f, 1f); p[K.musicOn] = n.musicOn; p[K.sfxOn] = n.sfxOn
        p[K.haptics] = n.haptics; p[K.quality] = n.quality.name; p[K.cam] = n.camSensitivity.coerceIn(0f, 1f)
    }
    /** Resets progress only (settings are kept). Caller must have obtained explicit confirmation. */
    suspend fun resetProgress() = ds.edit { p -> p.remove(K.unlocked); p.remove(K.stars); p.remove(K.best); p.remove(K.current); p.remove(K.saved); p.remove(K.daily); p.remove(K.tutorial) }
}
