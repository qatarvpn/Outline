package com.neonlogic3d.domain.solver

import com.neonlogic3d.domain.model.*

data class Solution(val moves: Int, val solution: Board)

/** Exhaustive minimum-move solver over simple source->target paths (independent of the BFS validator). */
object Solver {
    private class Option(val mask: Int, val cost: Int, val orientation: Int)
    private class Overflow : RuntimeException()

    private fun options(t: Tile): List<Option> {
        if (!t.type.connectable) return emptyList()
        if (!t.rotatable) return listOf(Option(t.mask, 0, t.orientation))
        val best = HashMap<Int, Option>()
        for (k in 0..3) {
            val o = (t.orientation + k) % 4; val m = Dir.rotate(t.type.baseMask, o)
            val cur = best[m]; if (cur == null || cur.cost > k) best[m] = Option(m, k, o)
        }
        return best.values.toList()
    }

    fun solve(board: Board, nodeCap: Int = 2_000_000): Solution? {
        val s = board.find(TileType.SOURCE).singleOrNull() ?: return null
        val g = board.find(TileType.TARGET).singleOrNull() ?: return null
        val opts = Array(board.rows) { r -> Array(board.cols) { c -> options(board[r, c]) } }
        var bestCost = Int.MAX_VALUE; var bestPath: List<Pair<Pos, Int>>? = null; var nodes = 0
        val visited = Array(board.rows) { BooleanArray(board.cols) }
        val chosen = ArrayList<Pair<Pos, Int>>()
        fun dfs(p: Pos, back: Int, cost: Int) {
            if (++nodes > nodeCap) throw Overflow()
            for (o in opts[p.r][p.c]) {
                if (back != 0 && o.mask and back == 0) continue
                val nc = cost + o.cost
                if (nc >= bestCost) continue
                if (p == g) { bestCost = nc; bestPath = chosen + (p to o.orientation); continue }
                chosen.add(p to o.orientation)
                for (d in Dir.ALL) {
                    if (o.mask and d == 0 || d == back) continue
                    val nr = p.r + Dir.dr(d); val ncc = p.c + Dir.dc(d)
                    if (!board.inBounds(nr, ncc) || visited[nr][ncc] || opts[nr][ncc].isEmpty()) continue
                    visited[nr][ncc] = true
                    dfs(Pos(nr, ncc), Dir.opposite(d), nc)
                    visited[nr][ncc] = false
                }
                chosen.removeAt(chosen.size - 1)
            }
        }
        visited[s.r][s.c] = true
        try { dfs(s, 0, 0) } catch (_: Overflow) { return null }
        val path = bestPath ?: return null
        var sol = board
        for ((p, o) in path) sol = sol.withTile(p.r, p.c, board[p].copy(orientation = o))
        return Solution(bestCost, sol)
    }
}
