package com.neonlogic3d

import com.neonlogic3d.data.levels.LevelParser
import com.neonlogic3d.domain.model.*
import com.neonlogic3d.domain.puzzle.*
import com.neonlogic3d.domain.solver.Solver
import org.junit.Assert.*
import org.junit.Test
import java.io.File

class LevelValidationTest {
    private val levels by lazy {
        val f = listOf("src/main/assets/levels.json", "app/src/main/assets/levels.json").map(::File).first { it.exists() }
        LevelParser.parse(f.readText())
    }
    @Test fun hundredLevelsInFiveChapters() {
        assertEquals(100, levels.size)
        assertEquals((1..100).toList(), levels.map { it.id })
        for (ch in 1..5) assertEquals(20, levels.count { it.chapter == ch })
    }
    @Test fun everyLevelIsStructurallyValid() {
        for (l in levels) {
            val b = l.board
            assertTrue("grid ${l.id}", b.rows in 3..8 && b.cols in 3..8)
            assertEquals("one source ${l.id}", 1, b.find(TileType.SOURCE).size)
            assertEquals("one target ${l.id}", 1, b.find(TileType.TARGET).size)
            assertTrue("par ${l.id}", l.par >= 1)
        }
    }
    @Test fun noLevelStartsSolved() { for (l in levels) assertFalse("level ${l.id} starts solved", Connectivity.evaluate(l.board).solved) }
    @Test fun intendedSolutionSatisfiesRulesAndMatchesPar() {
        for (l in levels) {
            assertTrue("solution ${l.id}", Connectivity.evaluate(l.solution).solved)
            var moves = 0
            for (r in 0 until l.board.rows) for (c in 0 until l.board.cols) {
                val a = l.board[r, c]; val s = l.solution[r, c]
                assertEquals(a.type, s.type)
                if (!a.rotatable) assertEquals("fixed tile changed in ${l.id}", a.orientation, s.orientation)
                else moves += (s.orientation - a.orientation + 4) % 4
            }
            assertEquals("par ${l.id}", l.par, moves)
        }
    }
    @Test fun solverAgreesOnMinimumMoves() {
        for (l in levels) {
            val s = Solver.solve(l.board)
            assertNotNull("level ${l.id} unsolvable", s)
            assertEquals("par ${l.id}", l.par, s!!.moves)
        }
    }
    @Test fun playingTheSolutionCompletesTheLevelThroughTheEngine() {
        for (l in levels) {
            val e = PuzzleEngine(l)
            for (r in 0 until l.board.rows) for (c in 0 until l.board.cols) {
                val turns = (l.solution[r, c].orientation - l.board[r, c].orientation + 4) % 4
                repeat(turns) { if (!e.state.completed) assertTrue(e.rotate(r, c)) }
            }
            assertTrue("level ${l.id}", e.state.completed)
            assertTrue(e.state.moves <= l.par)
        }
    }
}
