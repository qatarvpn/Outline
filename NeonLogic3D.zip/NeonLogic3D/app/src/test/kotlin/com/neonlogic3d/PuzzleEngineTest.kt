package com.neonlogic3d

import com.neonlogic3d.domain.model.*
import com.neonlogic3d.domain.puzzle.*
import com.neonlogic3d.data.levels.LevelParser
import org.junit.Assert.*
import org.junit.Test

private fun board(vararg rows: String) = LevelParser.parseBoard(rows.toList(), rows.size, rows[0].trim().split(" ").size)
private fun level(b: Board, sol: Board = b, par: Int = 1) = Level(1, 1, b, sol, par, 1)

class PuzzleEngineTest {
    @Test fun portsOfEveryType() {
        assertEquals(Dir.N or Dir.S, Tile(TileType.STRAIGHT, 0, false).mask)
        assertEquals(Dir.N or Dir.E, Tile(TileType.ELBOW, 0, false).mask)
        assertEquals(Dir.N or Dir.E or Dir.W, Tile(TileType.TEE, 0, false).mask)
        assertEquals(15, Tile(TileType.CROSS, 0, false).mask)
        assertEquals(Dir.N, Tile(TileType.SOURCE, 0, true).mask)
        assertEquals(0, Tile(TileType.BLOCKED, 0, true).mask)
    }
    @Test fun rotationsAtAllOrientations() {
        val expectedStraight = intArrayOf(Dir.N or Dir.S, Dir.E or Dir.W, Dir.N or Dir.S, Dir.E or Dir.W)
        val expectedElbow = intArrayOf(Dir.N or Dir.E, Dir.E or Dir.S, Dir.S or Dir.W, Dir.W or Dir.N)
        val expectedTee = intArrayOf(Dir.N or Dir.E or Dir.W, Dir.N or Dir.E or Dir.S, Dir.E or Dir.S or Dir.W, Dir.S or Dir.W or Dir.N)
        for (o in 0..3) {
            assertEquals(expectedStraight[o], Tile(TileType.STRAIGHT, o, false).mask)
            assertEquals(expectedElbow[o], Tile(TileType.ELBOW, o, false).mask)
            assertEquals(expectedTee[o], Tile(TileType.TEE, o, false).mask)
            assertEquals(15, Tile(TileType.CROSS, o, false).mask)
        }
        val t = Tile(TileType.ELBOW, 3, false)
        assertEquals(Tile(TileType.ELBOW, 0, false), t.rotatedClockwise()) // wraps 3 -> 0
    }
    @Test fun validPathIsSolved() {
        val b = board("O1 I1 G3")
        assertTrue(Connectivity.evaluate(b).solved)
        assertEquals(3, Connectivity.evaluate(b).path.size)
    }
    @Test fun reciprocalPortsRequired() {
        // elbow at middle touches both neighbours visually but has no west port
        val b = board("O1 L0 G3")
        assertFalse(Connectivity.evaluate(b).solved)
    }
    @Test fun disconnectedAndDeadEnds() {
        assertFalse(Connectivity.evaluate(board("O1 I0 G3")).solved)
        assertFalse(Connectivity.evaluate(board("O1 #0 G3")).solved)
        assertFalse(Connectivity.evaluate(board("O1 .0 G3")).solved)
        // dead end: path turns into a straight pointing away
        assertFalse(Connectivity.evaluate(board("O1 L1 G3", "I0 I0 I0")).solved)
    }
    @Test fun invalidSourceTargetConfigs() {
        assertFalse(Connectivity.evaluate(board("I1 I1 G3")).solved)          // no source
        assertFalse(Connectivity.evaluate(board("O1 I1 I1")).solved)          // no target
        assertFalse(Connectivity.evaluate(board("O1 O1 G3")).solved)          // two sources
        assertFalse(Connectivity.evaluate(board("O0 I1 G3")).solved)          // source facing away
    }
    @Test fun junctionsAndLoops() {
        // T with dangling stub still solves under the default rule
        assertTrue(Connectivity.evaluate(board("O1 T0 G3", "I0 I0 I0")).let { it.solved })
        // loop: 2x2 ring plus tail; BFS must terminate and solve
        val loop = board("O1 X0 X0 G3", "#0 L0 L3 #0")
        assertTrue(Connectivity.evaluate(loop).solved)
        // cross connects all four sides
        assertTrue(Connectivity.evaluate(board("O1 X0 G3")).solved)
    }
    @Test fun movesAndRestartAndCompletion() {
        val b = board("O1 I0 G3")
        val e = PuzzleEngine(level(b))
        assertFalse(e.rotate(0, 0)); assertFalse(e.rotate(0, 2)) // fixed tiles
        assertEquals(0, e.state.moves)
        assertTrue(e.rotate(0, 1))
        assertEquals(1, e.state.moves); assertTrue(e.state.completed)
        assertFalse(e.rotate(0, 1)); assertEquals(1, e.state.moves) // input ignored after completion
        e.restart(); assertEquals(0, e.state.moves); assertFalse(e.state.completed); assertEquals(b, e.state.board)
    }
    @Test fun undoRestoresStateAndCounter() {
        val e = PuzzleEngine(level(board("O1 I0 L0 G3")))
        e.rotate(0, 1); e.rotate(0, 2)
        assertEquals(2, e.state.moves)
        assertTrue(e.undo()); assertEquals(1, e.state.moves)
        assertTrue(e.undo()); assertEquals(0, e.state.moves)
        assertFalse(e.undo())
    }
    @Test fun hintCountedSeparatelyAndNeverMutatesBoard() {
        val e = PuzzleEngine(level(board("O1 I0 G3")))
        val before = e.state.board
        assertNotNull(e.hint())
        assertEquals(1, e.state.hints); assertEquals(0, e.state.moves); assertEquals(before, e.state.board)
    }
    @Test fun starsAndRestoreValidation() {
        assertEquals(3, PuzzleEngine.stars(5, 5, 0)); assertEquals(2, PuzzleEngine.stars(5, 5, 1))
        assertEquals(2, PuzzleEngine.stars(7, 5, 0)); assertEquals(1, PuzzleEngine.stars(9, 5, 0))
        val lv = level(board("O1 I0 G3"))
        assertNull(PuzzleEngine.restore(lv, listOf(1, 1), 0, 0))              // wrong size
        assertNull(PuzzleEngine.restore(lv, listOf(0, 0, 0), 0, 0))           // fixed tile orientation changed
        assertNull(PuzzleEngine.restore(lv, listOf(1, 1, 3), 1, 0))           // already solved
        assertNotNull(PuzzleEngine.restore(lv, listOf(1, 2, 3), 3, 1))
    }
}
