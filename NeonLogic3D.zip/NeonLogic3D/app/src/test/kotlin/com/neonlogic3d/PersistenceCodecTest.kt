package com.neonlogic3d

import com.neonlogic3d.data.persistence.*
import org.junit.Assert.*
import org.junit.Test

class PersistenceCodecTest {
    @Test fun mapRoundTripAndCorruption() {
        val m = mapOf(1 to 3, 7 to 2)
        assertEquals(m, ProgressStore.decodeMap(ProgressStore.encodeMap(m), 100))
        assertEquals(emptyMap<Int, Int>(), ProgressStore.decodeMap("garbage,1:x,:3,500:2", 100))
        assertEquals(mapOf(2 to 1), ProgressStore.decodeMap("2:1,999:3", 100))
    }
    @Test fun savedPuzzleRoundTripAndRejectsBadData() {
        val s = SavedPuzzle(12, listOf(0, 1, 2, 3, 0, 1), 4, 1)
        assertEquals(s, ProgressStore.decodeSaved(ProgressStore.encodeSaved(s)))
        assertNull(ProgressStore.decodeSaved("v2|1|0|0|0123")); assertNull(ProgressStore.decodeSaved("v1|1|0|0|0129"))
        assertNull(ProgressStore.decodeSaved(null)); assertNull(ProgressStore.decodeSaved("v1|a|0|0|01"))
    }
}
